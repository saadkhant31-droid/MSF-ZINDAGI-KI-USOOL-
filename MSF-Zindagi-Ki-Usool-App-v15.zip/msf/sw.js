const C='msf-usool-v15';
const F=['./','./index.html','./manifest.json','./icons/icon-192.png','./icons/icon-512.png','./icons/logo.png','./icons/profile.png','./fonts/al-mushaf-quran.ttf','./fonts/al-majeed-quranic.ttf','./fonts/al-qalam-quran.ttf','./fonts/alqalam-shekastah.ttf'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(F)));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))));self.clients.claim()});
/* بڑا اردو فونٹ پہلی بار لوڈ ہونے پر خود بخود کیش ہو جاتا ہے */
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{if(res&&res.ok&&e.request.url.includes('/fonts/')){const cp=res.clone();caches.open(C).then(c=>c.put(e.request,cp))}return res})))});
