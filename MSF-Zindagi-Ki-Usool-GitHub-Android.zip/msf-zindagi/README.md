# میرا روزانہ ریکارڈ — MSF Zindagi Ki Usool

بہتر عادات اور صحت مند زندگی کا روزانہ ریکارڈ۔ ایک ہی کوڈ سے **ویب/PWA ایپ** اور **اینڈرائیڈ ایپ (APK)** دونوں بنتی ہیں۔
Daily habit tracker (Urdu, RTL). One codebase → PWA + Android APK (WebView wrapper, built by GitHub Actions).

## فولڈرز
| فولڈر | کیا ہے |
|---|---|
| `web/` | پوری ایپ (`index.html`، فونٹس، آئیکن، `sw.js`) |
| `android/` | اینڈرائیڈ پروجیکٹ — `web/` کو اندر assets کے طور پر پیک کرتا ہے |
| `.github/workflows/android.yml` | ہر push پر APK بناتا ہے |
| `.github/workflows/pages.yml` | `web/` کو GitHub Pages پر چھاپتا ہے (اختیاری) |
| `docs/design/` | حوالہ ڈیزائن کی تصویریں |

## APK کیسے ملے گی (گِٹ ہب پر)
1. GitHub پر نئی (خالی) repository بنائیں، مثلاً `mera-rozana-record`۔
2. اس فولڈر کا سارا مواد اپ لوڈ/push کریں:
   ```bash
   git init
   git add .
   git commit -m "پہلا ورژن"
   git branch -M main
   git remote add origin https://github.com/<آپ-کا-نام>/mera-rozana-record.git
   git push -u origin main
   ```
3. repository میں **Actions** ٹیب کھولیں ← **Android APK بنائیں** چلنے دیں (تقریباً 3–6 منٹ)۔
4. مکمل ہونے پر اسی رن کے صفحے پر نیچے **Artifacts** میں `MeraRozanaRecord-debug-apk` ڈاؤن لوڈ کریں، زپ کھولیں، `app-debug.apk` فون میں انسٹال کریں
   (فون کی سیٹنگز میں «نامعلوم ذرائع سے انسٹال» کی اجازت دینی ہوگی)۔

> اگر Actions بند ہوں تو repository کی **Settings → Actions → General** میں فعال کریں۔

## دستخط شدہ (signed) release APK — اختیاری
Play Store یا مستقل انسٹال کے لیے:
```bash
keytool -genkeypair -v -keystore release.jks -alias msf -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks     # جو نتیجہ آئے وہ نیچے KEYSTORE_BASE64 میں رکھیں
```
repository **Settings → Secrets and variables → Actions** میں یہ 4 secrets بنائیں:
`KEYSTORE_BASE64`، `KEYSTORE_PASSWORD`، `KEY_ALIAS`، `KEY_PASSWORD`
پھر workflow خود `MeraRozanaRecord-release-apk` بھی بنا دے گا۔ `release.jks` کبھی repository میں نہ ڈالیں۔

## ویب ورژن (اختیاری)
Settings → Pages → Source: **GitHub Actions**۔ اس کے بعد `web/` میں ہر تبدیلی خود چھپ جائے گی، اور فون کے Chrome میں «Add to Home screen» سے بھی انسٹال ہو سکتی ہے۔

## ایپ میں تبدیلی کیسے کریں
صرف `web/index.html` میں تبدیلی کریں اور push کریں — APK اسی سے دوبارہ بنے گی۔ ورژن بڑھانا ہو تو `android/app/build.gradle` میں `versionCode`/`versionName` بدلیں۔

## نوٹ
- سارا ڈیٹا فون کے اندر محفوظ رہتا ہے، انٹرنیٹ کی ضرورت نہیں۔
- اینڈرائیڈ ایپ میں: بیک اپ «ڈاؤن لوڈز» فولڈر میں محفوظ ہوتا ہے، بیک بٹن پچھلی اسکرین پر لے جاتا ہے، اور یاد دہانی کی اطلاعات (اجازت کے بعد) ایپ چلتے ہوئے آتی ہیں۔
- «نماز کے وقت خودکار خاموش موڈ» کی ترجیح ابھی صرف محفوظ ہوتی ہے؛ فون کو واقعی خاموش کرنے کی سہولت اگلے مرحلے میں شامل ہوگی۔
