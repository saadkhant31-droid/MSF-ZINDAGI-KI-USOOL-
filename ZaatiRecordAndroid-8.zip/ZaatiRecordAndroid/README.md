# Zaati Record MSF (Android)
Offline Urdu personal-record app. UI lives in app/src/main/assets/index.html.
Push to GitHub -> Actions tab -> Build APK -> download artifact "Zaati-Record-APK".
