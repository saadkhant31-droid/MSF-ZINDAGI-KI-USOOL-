package com.msf.zaati;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private static final int FILE_REQ = 101;
    private WebView web;
    private ValueCallback<Uri[]> fileCb;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#0B4D2C"));
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        // Gallery picker for <input type="file"> (event photo, profile photo, backup restore).
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });
        // Native share sheet for "share event" buttons.
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void share(final String text) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(i, "Share"));
                    }
                });
            }

            @JavascriptInterface
            public void copy(final String text) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Zaati", text));
                    }
                });
            }

            @JavascriptInterface
            public void openUrl(final String url) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                        } catch (Exception e) { }
                    }
                });
            }

            @JavascriptInterface
            public void rotate(final boolean on) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setRequestedOrientation(on ? ActivityInfo.SCREEN_ORIENTATION_SENSOR : ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                    }
                });
            }

            @JavascriptInterface
            @SuppressWarnings("deprecation")
            public void vibrate(int ms) {
                Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (vb != null) vb.vibrate(ms);
            }

            @JavascriptInterface
            public String saveFile(String name, String text) {
                try {
                    byte[] data = text.getBytes("UTF-8");
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.Downloads.DISPLAY_NAME, name);
                        cv.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                        cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                        Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        OutputStream o = getContentResolver().openOutputStream(u);
                        o.write(data);
                        o.close();
                        return "Downloads/" + name;
                    }
                    File f = new File(getExternalFilesDir(null), name);
                    FileOutputStream o = new FileOutputStream(f);
                    o.write(data);
                    o.close();
                    return f.getAbsolutePath();
                } catch (Exception e) {
                    return "";
                }
            }
        }, "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        // Let the page handle "back" (close dialog / previous tab / home) first.
        web.evaluateJavascript("(function(){return window.zBack?zBack():false})()", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String r) {
                if (!"true".equals(r)) MainActivity.super.onBackPressed();
            }
        });
    }
}
