Kohat Prayer Times — January to December
Text files converted from the 12 supplied prayer-time screenshots.
The year and Hijri month/year headings have been removed.
OCR can misread some digits or punctuation, so verify unclear entries against the original screenshots.
Times are labelled Pakistan Standard Time; Asr method is Hanafi.
