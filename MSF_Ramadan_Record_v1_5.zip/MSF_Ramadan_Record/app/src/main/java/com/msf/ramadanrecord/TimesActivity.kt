package com.msf.ramadanrecord

import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.LocalTime

class TimesActivity : BaseActivity() {

    private val today: LocalDate = LocalDate.now()
    private val dk: String get() = today.toString()

    // sehri form values
    private var shWoke = ""
    private var shAte = ""
    private var shBefore = ""
    private var iftOpened = ""
    private lateinit var shFood: EditText
    private lateinit var shNote: EditText
    private lateinit var ifFood: EditText
    private lateinit var ifWith: EditText
    private lateinit var ifNote: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun countdown(): String {
        val now = LocalTime.now()
        val nowMin = now.hour * 60 + now.minute
        val s = Store.sehri(this)
        val f = Store.iftar(this)
        val label: String
        val diff: Int
        if (nowMin < s) {
            label = "سحری ختم ہونے میں باقی"
            diff = s - nowMin
        } else if (nowMin < f) {
            label = "افطار میں باقی"
            diff = f - nowMin
        } else {
            label = "اگلی سحری میں باقی"
            diff = 24 * 60 - nowMin + s
        }
        return "$label: ${diff / 60} گھنٹے ${diff % 60} منٹ"
    }

    private fun render() {
        val content = heroScreen("سحری اور افطاری", "اللہ کے حکم سے روزہ، اللہ کی رضا کے لیے", 1)

        // load saved values for today
        shWoke = Store.getStr(this, "sh:$dk:woke")
        shAte = Store.getStr(this, "sh:$dk:ate")
        shBefore = Store.getStr(this, "sh:$dk:before")
        iftOpened = Store.getStr(this, "if:$dk:opened")

        val cd = card(content, C.DARK)
        cd.addView(tv(countdown(), 14f, Color.WHITE, true))

        val panels = LinearLayout(this)
        panels.orientation = LinearLayout.HORIZONTAL
        panels.addView(iftarPanel(), lp(0, WRAP, 1f).margins(dp(4), 0, dp(4), 0))
        panels.addView(sehriPanel(), lp(0, WRAP, 1f).margins(dp(4), 0, dp(4), 0))
        content.addView(panels, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))

        val dua = tv("اے اللہ! ہمیں سحری اور افطار کی برکتیں نصیب فرما", 14f, C.TEXT)
        dua.background = bg(C.col("#E8F2DC"), 14, C.col("#CFE3BC"), 1)
        dua.setPadding(dp(16), dp(14), dp(16), dp(14))
        content.addView(dua, lp(MATCH, WRAP).margins(dp(4), dp(12), dp(4), 0))

        heading(content, "سحری کی نیت")
        val d1 = card(content)
        d1.addView(tv("وَبِصَوْمِ غَدٍ نَّوَيْتُ مِنْ شَهْرِ رَمَضَانَ", 18f, C.DARK, true))
        d1.addView(tv("ترجمہ: میں نے ماہِ رمضان کے کل کے روزے کی نیت کی۔", 13f, C.TEXT, false, Gravity.START))
        heading(content, "افطار کی دعا")
        val d2 = card(content)
        d2.addView(tv("اللَّهُمَّ لَكَ صُمْتُ وَعَلَىٰ رِزْقِكَ أَفْطَرْتُ", 18f, C.DARK, true))
        d2.addView(tv("ترجمہ: اے اللہ! میں نے تیرے لیے روزہ رکھا اور تیرے رزق سے افطار کیا۔", 13f, C.TEXT, false, Gravity.START))
    }

    // ---------- shared building blocks ----------
    private fun panelShell(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.background = bg(C.CARD, 18, C.BORDER, 1)
        p.setPadding(dp(5), 0, dp(5), dp(8))
        return p
    }

    private fun header(p: LinearLayout, icon: String, title: String, sub: String, c1: Int, c2: Int) {
        val h = LinearLayout(this)
        h.orientation = LinearLayout.VERTICAL
        h.gravity = Gravity.CENTER
        val r = dp(18).toFloat()
        val g = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c1, c2))
        g.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        h.background = g
        h.setPadding(dp(6), dp(12), dp(6), dp(12))
        h.addView(tv(icon, 30f, Color.WHITE))
        h.addView(tv(title, 26f, C.col("#F6D76A"), true))
        h.addView(tv(sub, 10f, Color.WHITE))
        p.addView(h, lp(MATCH, WRAP).margins(-dp(5), 0, -dp(5), dp(6)))
    }

    private fun small(p: LinearLayout): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(C.SURFACE, 12, C.BORDER, 1)
        c.setPadding(dp(8), dp(8), dp(8), dp(8))
        p.addView(c, lp(MATCH, WRAP).margins(0, dp(4), 0, dp(4)))
        return c
    }

    private fun dateBlock(p: LinearLayout) {
        val c = small(p)
        c.orientation = LinearLayout.HORIZONTAL
        val a = LinearLayout(this)
        a.orientation = LinearLayout.VERTICAL
        a.gravity = Gravity.CENTER
        a.addView(tv("📅 اسلامی تاریخ", 10f, C.MUTED))
        a.addView(tv(Dates.hijri(today, Store.offset(this)), 11f, C.DARK, true))
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.gravity = Gravity.CENTER
        b.addView(tv("📅 تاریخ", 10f, C.MUTED))
        b.addView(tv(Dates.greg(today), 11f, C.DARK, true))
        b.addView(tv("(${Dates.urduDay(today)})", 10f, C.TEXT))
        c.addView(a, lp(0, WRAP, 1f))
        c.addView(b, lp(0, WRAP, 1f))
    }

    private fun timeRow(p: LinearLayout, label: String, minutes: Int, isSehri: Boolean) {
        val c = small(p)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.addView(tv("🕒", 22f, C.DARK), lp(WRAP, WRAP))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(label, 11f, C.TEXT, true, Gravity.START))
        col.addView(tv(Dates.fmtTime(minutes), 17f, C.DARK, true, Gravity.START))
        c.addView(col, lp(0, WRAP, 1f).margins(dp(6), 0, 0, 0))
        c.addView(tv("✏️", 14f, Color.BLACK), lp(WRAP, WRAP))
        c.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                if (isSehri) Store.setSehri(this, h * 60 + m) else Store.setIftar(this, h * 60 + m)
                render()
            }, minutes / 60, minutes % 60, false).show()
        }
    }

    private fun yesNo(p: LinearLayout, icon: String, q: String, initial: String, onChange: (String) -> Unit) {
        val c = small(p)
        c.addView(tv("$icon $q", 11f, C.TEXT, true, Gravity.START))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        var value = initial
        val yes = tv("ہاں", 12f, Color.WHITE, true)
        val no = tv("نہیں", 12f, Color.WHITE, true)
        fun paint() {
            yes.text = if (value == "1") "ہاں ✓" else "ہاں"
            yes.background = bg(if (value == "1") C.GREEN else C.col("#B9C0BB"), 14)
            no.background = bg(if (value == "0") C.col("#7A8580") else C.col("#D5DAD6"), 14)
            no.setTextColor(if (value == "0") Color.WHITE else C.col("#55605A"))
        }
        paint()
        yes.setPadding(dp(14), dp(6), dp(14), dp(6))
        no.setPadding(dp(14), dp(6), dp(14), dp(6))
        yes.setOnClickListener { value = "1"; paint(); onChange(value) }
        no.setOnClickListener { value = "0"; paint(); onChange(value) }
        row.addView(no, lp(WRAP, WRAP).margins(0, 0, dp(6), 0))
        row.addView(yes, lp(WRAP, WRAP))
        c.addView(row, lp(WRAP, WRAP).margins(0, dp(6), 0, 0))
    }

    private fun field(p: LinearLayout, icon: String, label: String, hint: String, initial: String, lines: Int): EditText {
        val c = small(p)
        c.addView(tv("$icon $label", 11f, C.TEXT, true, Gravity.START))
        val e = EditText(this)
        e.setText(initial)
        e.hint = hint
        e.textSize = 12f
        e.minLines = lines
        e.gravity = Gravity.TOP or Gravity.START
        e.background = bg(C.col("#F1F1EC"), 10)
        e.setPadding(dp(8), dp(8), dp(8), dp(8))
        c.addView(e, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))
        return e
    }

    private fun saveBtn(p: LinearLayout, text: String, color: Int, onClick: () -> Unit) {
        p.addView(button("💾 $text", color, onClick).also { it.textSize = 12f }, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))
    }

    // ---------- Sehri ----------
    private fun sehriPanel(): View {
        val p = panelShell()
        header(p, "🍲", "سحری", "روزے کی برکت سحری میں ہے", C.col("#0B3D2E"), C.col("#1E7A3C"))
        dateBlock(p)
        timeRow(p, "سحری کا وقت", Store.sehri(this), true)
        yesNo(p, "⏰", "سحری کے لیے وقت پر اٹھے؟", shWoke) { shWoke = it }
        yesNo(p, "🍴", "سحری میں کھانا کھایا؟", shAte) { shAte = it }
        shFood = field(p, "🍚", "سحری میں کیا کھایا؟", "دودھ، روٹی، کھجور", Store.getStr(this, "sh:$dk:food"), 1)
        yesNo(p, "🕌", "فجر سے پہلے سحری مکمل کی؟", shBefore) { shBefore = it }
        shNote = field(p, "📝", "سحری کے متعلق ذاتی نوٹ", "یہاں نوٹ لکھیں", Store.getStr(this, "sh:$dk:note"), 2)
        saveBtn(p, "سحری کا ریکارڈ محفوظ کریں", C.DARK) {
            Store.putStr(this, "sh:$dk:woke", shWoke)
            Store.putStr(this, "sh:$dk:ate", shAte)
            Store.putStr(this, "sh:$dk:before", shBefore)
            Store.putStr(this, "sh:$dk:food", shFood.text.toString().trim())
            Store.putStr(this, "sh:$dk:note", shNote.text.toString().trim())
            toast("سحری کا ریکارڈ محفوظ ہو گیا")
        }
        return p
    }

    // ---------- Iftar ----------
    private fun iftarPanel(): View {
        val p = panelShell()
        header(p, "🥣", "افطاری", "افطار میں برکت ہے، صحت ہے", C.col("#5B2A86"), C.col("#E8921A"))
        dateBlock(p)
        timeRow(p, "افطار کا وقت", Store.iftar(this), false)
        ifFood = field(p, "🍴", "افطار میں کیا کھایا؟", "کھجور، پانی، کھانا", Store.getStr(this, "if:$dk:food"), 1)
        ifWith = field(p, "🥣", "افطار کس چیز سے کیا؟", "کھجور اور پانی سے", Store.getStr(this, "if:$dk:with"), 1)
        yesNo(p, "✅", "روزہ کھولا یا نہیں؟", iftOpened) { iftOpened = it }
        ifNote = field(p, "📝", "افطار کے متعلق ذاتی نوٹ", "یہاں نوٹ لکھیں", Store.getStr(this, "if:$dk:note"), 2)
        saveBtn(p, "افطاری کا ریکارڈ محفوظ کریں", C.col("#C98A12")) {
            Store.putStr(this, "if:$dk:food", ifFood.text.toString().trim())
            Store.putStr(this, "if:$dk:with", ifWith.text.toString().trim())
            Store.putStr(this, "if:$dk:opened", iftOpened)
            Store.putStr(this, "if:$dk:note", ifNote.text.toString().trim())
            toast("افطاری کا ریکارڈ محفوظ ہو گیا")
        }
        return p
    }
}
