package com.msf.ramadanrecord

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AlertDialog

class QuranActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val content = screen("قرآن پاک کا ریکارڈ", 7)

        val head = card(content, C.col("#DFF3EE"))
        val summary = tv("", 18f, C.TEAL, true)
        head.addView(summary)
        val khatam = tv("", 13f, C.TEXT)
        head.addView(khatam)
        fun refresh() {
            summary.text = "پڑھے گئے پارے: ${Store.parasCount(this)} / 30"
            khatam.text = "مکمل ختم: ${Store.khatam(this)}"
        }
        refresh()

        heading(content, "جو پارہ مکمل پڑھا اس پر ٹیپ کریں")
        val box = card(content)
        grid(box, 30, 6, { Store.paraRead(this, it) }, { Store.togglePara(this, it) }, C.TEAL) { refresh() }

        addButton(content, "نیا ختم شروع کریں", C.TEAL) {
            AlertDialog.Builder(this)
                .setMessage(
                    if (Store.parasCount(this) >= 30) "ختم مکمل ہو گیا۔ ختم کی تعداد میں اضافہ کر کے نیا دور شروع کریں؟"
                    else "ابھی 30 پارے مکمل نہیں ہوئے۔ پھر بھی نشان صاف کر کے نیا دور شروع کریں؟"
                )
                .setPositiveButton("ہاں") { _, _ ->
                    Store.newKhatamRound(this)
                    render()
                }
                .setNegativeButton("نہیں", null)
                .show()
        }
    }
}
