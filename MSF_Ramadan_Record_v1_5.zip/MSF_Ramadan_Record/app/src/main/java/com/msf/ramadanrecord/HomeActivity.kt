package com.msf.ramadanrecord

import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate
import kotlin.math.max

class HomeActivity : BaseActivity() {

    private class Item(val icon: String, val label: String, val color: Int, val target: Class<*>)

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        window.statusBarColor = C.DARK
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.layoutDirection = View.LAYOUT_DIRECTION_RTL
        outer.setBackgroundColor(C.BG)

        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        outer.addView(scroll, lp(MATCH, 0, 1f))
        outer.addView(buildNav(0), lp(MATCH, WRAP))

        col.addView(banner(), lp(MATCH, dp(300)))
        col.addView(dateCard(), lp(MATCH, WRAP).margins(dp(12), -dp(30), dp(12), 0))
        col.addView(statsRow(), lp(MATCH, WRAP).margins(dp(6), dp(10), dp(6), 0))
        col.addView(timesAndPrayers(), lp(MATCH, WRAP).margins(dp(10), dp(8), dp(10), 0))
        col.addView(menuGrid(), lp(MATCH, WRAP).margins(dp(8), dp(4), dp(8), 0))
        col.addView(duaCard(), lp(MATCH, WRAP).margins(dp(12), dp(8), dp(12), dp(16)))
        setContentView(outer)
    }

    // ---------------- banner ----------------
    private fun banner(): View {
        val f = FrameLayout(this)
        f.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(C.col("#05241A"), C.col("#0E5A3A"), C.col("#A07F2B"))
        )

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        val logoLp = FrameLayout.LayoutParams(dp(140), dp(140), Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        logoLp.topMargin = dp(30)
        f.addView(logo, logoLp)

        val pill = tv("رمضان المبارک", 18f, Color.WHITE, true)
        pill.background = bg(C.DARK, 20, C.GOLD, 2)
        pill.setPadding(dp(26), dp(6), dp(26), dp(6))
        val pillLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        pillLp.bottomMargin = dp(82)
        f.addView(pill, pillLp)

        val sub = tv("اللہ کے قرب کی طرف ایک قدم", 12f, C.col("#F3E3A5"))
        val subLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        subLp.bottomMargin = dp(54)
        f.addView(sub, subLp)

        // menu button (top-left)
        val menuBtn = tv("☰", 22f, Color.WHITE, true)
        menuBtn.background = oval(C.DARK, C.GOLD, 2)
        val menuLp = FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.LEFT)
        menuLp.setMargins(dp(14), dp(14), 0, 0)
        menuBtn.setOnClickListener { showMenu(menuBtn) }
        f.addView(menuBtn, menuLp)

        // Ramadan day box (top-right)
        val total = Store.totalDays(this)
        val d = Store.ramadanDay(this)
        val label: String
        val big: String
        val small: String
        if (d in 1..total) {
            label = "رمضان کا دن"; big = d.toString(); small = "(Day)"
        } else if (d < 1) {
            label = "رمضان میں باقی"; big = (1 - d).toString(); small = "(Days)"
        } else {
            label = "رمضان مکمل"; big = "✓"; small = ""
        }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.background = bg(C.DARK, 14, C.GOLD, 2)
        box.setPadding(dp(12), dp(6), dp(12), dp(6))
        box.addView(tv(label, 10f, Color.WHITE))
        box.addView(tv(big, 28f, Color.WHITE, true))
        if (small.isNotEmpty()) box.addView(tv(small, 11f, Color.WHITE))
        val boxLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.RIGHT)
        boxLp.setMargins(0, dp(14), dp(14), 0)
        box.setOnClickListener { go(CalendarActivity::class.java) }
        f.addView(box, boxLp)
        return f
    }

    private fun showMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "سیٹنگز")
        pm.menu.add(0, 2, 1, "رپورٹس")
        pm.menu.add(0, 3, 2, "ایپ شیئر کریں")
        pm.menu.add(0, 4, 3, "ایپ کے بارے میں")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> go(SettingsActivity::class.java)
                2 -> go(ReportsActivity::class.java)
                3 -> {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, "MSF RamdanulMubarak Record - رمضان المبارک کا ریکارڈ رکھنے والی ایپ")
                    startActivity(Intent.createChooser(i, "شیئر کریں"))
                }
                4 -> AlertDialog.Builder(this)
                    .setTitle("MSF RamdanulMubarak Record")
                    .setMessage("روزے، نمازیں، قرآن پاک کی تلاوت اور ذاتی نوٹس کا ریکارڈ رکھنے کے لیے۔\n\nورژن 1.0")
                    .setPositiveButton("ٹھیک ہے", null)
                    .show()
            }
            true
        }
        pm.show()
    }

    // ---------------- date card ----------------
    private fun infoCol(label: String, big: String, small: String): View {
        val v = LinearLayout(this)
        v.orientation = LinearLayout.VERTICAL
        v.gravity = Gravity.CENTER
        v.addView(tv("📅 $label", 11f, C.MUTED))
        val b = tv(big, 15f, C.DARK, true)
        b.setPadding(0, dp(4), 0, 0)
        v.addView(b)
        if (small.isNotEmpty()) v.addView(tv(small, 12f, C.TEXT))
        return v
    }

    private fun divider(): View {
        val d = View(this)
        d.setBackgroundColor(C.BORDER)
        return d
    }

    private fun dateCard(): View {
        val today = LocalDate.now()
        val card = LinearLayout(this)
        card.orientation = LinearLayout.HORIZONTAL
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = bg(C.CARD, 18, C.BORDER, 1)
        card.elevation = dp(3).toFloat()
        card.setPadding(dp(6), dp(12), dp(6), dp(12))
        card.addView(infoCol("دن", Dates.urduDay(today), ""), lp(0, WRAP, 1f))
        card.addView(divider(), lp(dp(1), dp(44)))
        card.addView(infoCol("تاریخ (انگریزی)", Dates.greg(today), "(${Dates.eng(today)})"), lp(0, WRAP, 1.3f))
        card.addView(divider(), lp(dp(1), dp(44)))
        card.addView(infoCol("تاریخ (ہجری)", Dates.hijri(today, Store.offset(this)), ""), lp(0, WRAP, 1.2f))
        card.setOnClickListener { go(CalendarActivity::class.java) }
        return card
    }

    // ---------------- stats ----------------
    private fun statsRow(): View {
        val total = Store.totalDays(this)
        val kept = Store.keptCount(this)
        val qT = Store.qazaTotal(this)
        val qD = Store.qazaDone(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL

        fun add(icon: String, label: String, value: Int, color: Int, target: Class<*>) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(color, 14)
            c.setPadding(dp(2), dp(10), dp(2), dp(10))
            c.addView(tv(icon, 22f, Color.WHITE))
            val l = tv(label, 10f, Color.WHITE)
            l.minLines = 2
            l.maxLines = 2
            c.addView(l)
            c.addView(tv(value.toString(), 24f, Color.WHITE, true))
            c.setOnClickListener { go(target) }
            row.addView(c, lp(0, WRAP, 1f).margins(dp(3), 0, dp(3), 0))
        }

        add("⏱", "باقی قضا روزے", max(0, qT - qD), C.TEAL, QazaActivity::class.java)
        add("✔", "ادا کیے گئے قضا روزے", qD, C.ORANGE, QazaActivity::class.java)
        add("📄", "کل قضا روزے", qT, C.PURPLE, QazaActivity::class.java)
        add("✖", "باقی روزے", max(0, total - kept), C.RED, FastsActivity::class.java)
        add("✔", "رکھے گئے روزے", kept, C.BLUE, FastsActivity::class.java)
        add("🕌", "رمضان کے کل روزے", total, C.col("#0C4A2C"), FastsActivity::class.java)
        return row
    }

    // ---------------- times + prayers ----------------
    private fun timesAndPrayers(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(prayersCard(), lp(0, MATCH, 1.2f).margins(dp(4), 0, dp(4), 0))
        row.addView(timesCard(), lp(0, MATCH, 1f).margins(dp(4), 0, dp(4), 0))
        return row
    }

    private fun timeBox(title: String, icon: String, minutes: Int, tint: Int, titleColor: Int, isSehri: Boolean): View {
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL
        b.gravity = Gravity.CENTER
        b.background = bg(tint, 12)
        b.setPadding(dp(4), dp(8), dp(4), dp(8))
        b.addView(tv("$icon $title", 10f, titleColor, true))
        val t = tv(Dates.fmtTime(minutes), 12f, C.TEXT, true)
        t.background = bg(C.SURFACE, 10)
        t.setPadding(dp(4), dp(8), dp(4), dp(8))
        b.addView(t, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))
        b.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                if (isSehri) Store.setSehri(this, h * 60 + m) else Store.setIftar(this, h * 60 + m)
                render()
            }, minutes / 60, minutes % 60, false).show()
        }
        return b
    }

    private fun timesCard(): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.background = bg(C.CARD, 16, C.BORDER, 1)
        c.setPadding(dp(6), dp(8), dp(6), dp(8))
        c.addView(
            timeBox("افطار کا وقت", "🌴", Store.iftar(this), C.col("#FDEBC8"), C.col("#B8630A"), false),
            lp(0, MATCH, 1f).margins(dp(3), 0, dp(3), 0)
        )
        c.addView(
            timeBox("سحری کا وقت", "🍲", Store.sehri(this), C.col("#DDF6E3"), C.col("#1E7A3C"), true),
            lp(0, MATCH, 1f).margins(dp(3), 0, dp(3), 0)
        )
        return c
    }

    private fun prayersCard(): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(C.CARD, 16, C.BORDER, 1)
        c.setPadding(dp(6), dp(8), dp(6), dp(8))
        c.addView(tv("🕌 آج کی نمازیں", 14f, C.DARK, true))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val today = LocalDate.now().toString()
        for (i in 0 until 5) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            col.addView(tv(Dates.prayers[i], 11f, C.TEXT, true))
            val chk = tv("", 13f, Color.WHITE, true)
            val lbl = tv("", 9f, C.MUTED)
            fun paint(on: Boolean) {
                paintCheck(chk, on)
                lbl.text = if (on) "ادا کی" else "باقی"
            }
            paint(Store.prayerOn(this, today, i))
            col.setOnClickListener { paint(Store.togglePrayer(this, today, i)) }
            col.addView(chk, lp(dp(24), dp(24)).margins(0, dp(6), 0, dp(4)))
            col.addView(lbl)
            row.addView(col, lp(0, WRAP, 1f))
        }
        c.addView(row, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))
        return c
    }

    // ---------------- menu grid ----------------
    private fun menuCard(item: Item): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER
        c.background = bg(item.color, 14)
        c.setPadding(dp(2), dp(8), dp(2), dp(8))
        val icon = tv(item.icon, 18f, Color.BLACK)
        icon.background = oval(Color.WHITE)
        c.addView(icon, lp(dp(38), dp(38)))
        val l = tv(item.label, 11f, Color.WHITE, true)
        l.minLines = 2
        l.maxLines = 2
        l.setPadding(dp(2), dp(6), dp(2), 0)
        c.addView(l)
        c.setOnClickListener { go(item.target) }
        return c
    }

    private fun menuGrid(): View {
        val g = LinearLayout(this)
        g.orientation = LinearLayout.VERTICAL
        val r1 = listOf(
            Item("🍲", "سحری اور افطار", C.ORANGE, TimesActivity::class.java),
            Item("🌙", "نفلی روزے", C.PURPLE, NafliActivity::class.java),
            Item("⏳", "قضا روزوں کا ریکارڈ", C.col("#1B7BBE"), QazaActivity::class.java),
            Item("🥣", "رمضان کے فرض روزے", C.col("#2E8B3A"), FastsActivity::class.java)
        )
        val r2 = listOf(
            Item("📝", "ذاتی نوٹس", C.PURPLE, NotesActivity::class.java),
            Item("📊", "روزوں کی رپورٹس", C.BLUE, ReportsActivity::class.java),
            Item("📖", "قرآن پاک کا ریکارڈ", C.TEAL, QuranActivity::class.java),
            Item("🕌", "نمازوں کا ریکارڈ", C.RED, PrayersActivity::class.java)
        )
        for (r in listOf(r1, r2)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (m in r) row.addView(menuCard(m), lp(0, dp(104), 1f).margins(dp(4), dp(4), dp(4), dp(4)))
            g.addView(row, lp(MATCH, WRAP))
        }
        return g
    }

    private fun duaCard(): View {
        val t = tv(
            "اے اللہ! ہمیں رمضان کے روزے، نمازیں اور قرآن پاک کی تلاوت کرنے کی توفیق عطا فرما۔ آمین",
            14f, C.TEXT
        )
        t.setLineSpacing(0f, 1.3f)
        t.background = bg(C.col("#E8F2DC"), 14, C.col("#CFE3BC"), 1)
        t.setPadding(dp(16), dp(14), dp(16), dp(14))
        return t
    }
}
