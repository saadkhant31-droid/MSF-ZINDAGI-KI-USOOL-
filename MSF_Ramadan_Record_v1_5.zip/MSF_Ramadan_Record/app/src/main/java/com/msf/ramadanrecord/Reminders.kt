package com.msf.ramadanrecord

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.time.LocalDateTime
import java.time.ZoneId

object Reminders {
    val TITLES = arrayOf("سحری کی یاد دہانی", "افطار کی یاد دہانی", "نماز کی یاد دہانی", "قرآن پاک کی تلاوت")
    val SUBS = arrayOf("سحری سے پہلے جگائے", "افطار سے پہلے یاد دلائے", "نماز کا وقت یاد دلائے", "روزانہ تلاوت یاد دلائے")
    val BODIES = arrayOf(
        "سحری کا وقت قریب ہے، سحری کر لیں۔",
        "افطار کا وقت قریب ہے، دعا کی تیاری کریں۔",
        "نماز کا وقت ہو گیا ہے، نماز ادا کریں۔",
        "آج کی تلاوت کا وقت ہو گیا ہے۔"
    )
    const val COUNT = 4
    private const val CH_SOUND = "msf_rem_sound"
    private const val CH_SILENT = "msf_rem_silent"

    fun ensureChannels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val a = NotificationChannel(CH_SOUND, "یاد دہانیاں", NotificationManager.IMPORTANCE_HIGH)
        a.enableVibration(true)
        val b = NotificationChannel(CH_SILENT, "یاد دہانیاں (خاموش)", NotificationManager.IMPORTANCE_LOW)
        b.enableVibration(false)
        b.setSound(null, null)
        nm.createNotificationChannel(a)
        nm.createNotificationChannel(b)
    }

    private fun alarmIntent(c: Context, i: Int): PendingIntent {
        val intent = Intent(c, ReminderReceiver::class.java)
        intent.putExtra("i", i)
        return PendingIntent.getBroadcast(
            c, 100 + i, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(c: Context, i: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(alarmIntent(c, i))
        if (!Store.remOn(c, i)) return
        val m = Store.remMin(c, i)
        val now = LocalDateTime.now()
        var t = now.withHour(m / 60).withMinute(m % 60).withSecond(0).withNano(0)
        if (!t.isAfter(now)) t = t.plusDays(1)
        val ms = t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, ms, alarmIntent(c, i))
    }

    fun scheduleAll(c: Context) {
        ensureChannels(c)
        for (i in 0 until COUNT) schedule(c, i)
    }

    fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun show(c: Context, i: Int) {
        if (!canPost(c)) return
        ensureChannels(c)
        val sound = Store.soundOn(c)
        val open = PendingIntent.getActivity(
            c, 200, Intent(c, HomeActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(c, if (sound) CH_SOUND else CH_SILENT)
            .setSmallIcon(R.drawable.ic_bell)
            .setContentTitle(TITLES[i])
            .setContentText(BODIES[i])
            .setStyle(NotificationCompat.BigTextStyle().bigText(BODIES[i]))
            .setContentIntent(open)
            .setAutoCancel(true)
            .setPriority(if (sound) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_LOW)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(300 + i, n)
        } catch (e: SecurityException) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val i = intent.getIntExtra("i", 0).coerceIn(0, Reminders.COUNT - 1)
        if (Store.remOn(context, i)) Reminders.show(context, i)
        Reminders.schedule(context, i)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.scheduleAll(context)
    }
}
