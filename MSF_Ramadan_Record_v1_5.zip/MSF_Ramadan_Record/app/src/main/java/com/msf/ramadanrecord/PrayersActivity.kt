package com.msf.ramadanrecord

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate
import java.time.LocalTime

class PrayersActivity : BaseActivity() {

    private var sel: LocalDate = LocalDate.now()
    private var msgIdx = -1
    private lateinit var content: LinearLayout

    private val accent = intArrayOf(
        C.col("#1E8E3E"), C.col("#E8A317"), C.col("#EC4A67"),
        C.col("#7B3FC4"), C.col("#1F6FD0")
    )
    private val light = intArrayOf(
        C.col("#E6F4EA"), C.col("#FFF4D6"), C.col("#FFE4E9"),
        C.col("#EFE5FA"), C.col("#E1EEFC")
    )
    private val icons = arrayOf("🌅", "☀️", "🌇", "🌆", "🌙")
    private val rakats = intArrayOf(2, 4, 4, 3, 4)
    private val stLabel = arrayOf("باقی", "مکمل", "قضا", "چھوٹی")
    private val stTile = arrayOf("باقی", "پڑھی گئی", "قضا پڑھی", "چھوٹ گئی")

    private val msgs = arrayOf(
        arrayOf("نماز دین کا ستون ہے، اسے قائم رکھو، یہی سکون کی راہ ہے۔", "(اسلامی تعلیمات)"),
        arrayOf("بے شک نماز مومنوں پر مقررہ وقت پر فرض ہے۔", "(سورۃ النساء: 103)"),
        arrayOf("اور میری یاد کے لیے نماز قائم کرو۔", "(سورۂ طٰہٰ: 14)"),
        arrayOf("بے شک نماز بے حیائی اور برے کاموں سے روکتی ہے۔", "(سورۃ العنکبوت: 45)")
    )

    private val key: String get() = sel.toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        content = heroScreen("نمازوں کی ریکارڈز", "اللہ کے حکم کی پابندی ہی کامیابی ہے۔", 6)
        refresh()
    }

    // ---------------- helpers ----------------
    private data class Week(
        val elapsed: Int, val per: IntArray, val complete: Int,
        val qazaDays: Int, val missedDays: Int, val total: Int
    )

    private fun week(): Week {
        val ws = sel.minusDays((sel.dayOfWeek.value - 1).toLong())
        val today = LocalDate.now()
        val per = IntArray(5)
        var el = 0; var comp = 0; var qd = 0; var md = 0; var tot = 0
        for (k in 0 until 7) {
            val d = ws.plusDays(k.toLong())
            if (d.isAfter(today)) break
            el++
            var done = 0; var q = false; var m = false
            for (i in 0 until 5) {
                val s = Store.prayerStatus(this, d.toString(), i)
                if (s == 1 || s == 2) { per[i]++; done++ }
                if (s == 2) q = true
                if (s == 3) m = true
            }
            tot += done
            if (done == 5) comp++
            if (q) qd++
            if (m) md++
        }
        return Week(el, per, comp, qd, md, tot)
    }

    private fun topBg(color: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        val rr = dp(r).toFloat()
        g.cornerRadii = floatArrayOf(rr, rr, rr, rr, 0f, 0f, 0f, 0f)
        return g
    }

    private fun defaultNote(st: Int): String = when (st) {
        1 -> "وقت پر ادا کی"
        2 -> "قضا پڑھی"
        3 -> "چھوٹ گئی"
        else -> "-"
    }

    private fun setStatus(i: Int, st: Int) {
        Store.setPrayerStatus(this, key, i, st)
        if (st == 1 || st == 2) {
            if (Store.prayedTime(this, key, i) < 0) {
                val now = LocalTime.now()
                val m = if (sel == LocalDate.now()) now.hour * 60 + now.minute else Store.prayerTime(this, i)
                Store.setPrayedTime(this, key, i, m)
            }
        }
        refresh()
    }

    private fun pickTime(initial: Int, onPick: (Int) -> Unit) {
        val m = if (initial < 0) 0 else initial
        TimePickerDialog(this, { _, h, mi -> onPick(h * 60 + mi) }, m / 60, m % 60, false).show()
    }

    private fun statusDialog(i: Int) {
        val items = arrayOf("✔ مکمل (وقت پر ادا)", "⏱ قضا پڑھی", "✖ چھوٹ گئی", "○ باقی (ریکارڈ ہٹائیں)")
        val map = intArrayOf(1, 2, 3, 0)
        AlertDialog.Builder(this)
            .setTitle("${Dates.prayers[i]} کی حالت")
            .setItems(items) { _, which -> setStatus(i, map[which]) }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun noteDialog(i: Int) {
        val et = EditText(this)
        et.setText(Store.prayerNote(this, key, i))
        et.hint = "نوٹ لکھیں"
        val box = LinearLayout(this)
        box.setPadding(dp(20), dp(8), dp(20), 0)
        box.addView(et, lp(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("${Dates.prayers[i]} — نوٹ")
            .setView(box)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                Store.setPrayerNote(this, key, i, et.text.toString().trim())
                refresh()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun statusDot(st: Int): TextView {
        val sym: String
        val col: Int
        when (st) {
            1 -> { sym = "✔"; col = C.GREEN }
            2 -> { sym = "⏱"; col = C.ORANGE }
            3 -> { sym = "✖"; col = C.RED }
            else -> { sym = ""; col = C.col("#B8C0BA") }
        }
        val t = tv(sym, 12f, Color.WHITE, true)
        t.background = if (st == 0) oval(Color.WHITE, col, 2) else oval(col)
        return t
    }

    // ---------------- build ----------------
    private fun refresh() {
        content.removeAllViews()
        val today = LocalDate.now()
        val w = week()

        val title = if (sel == today) "آج کی نمازوں کا خلاصہ" else "${Dates.greg(sel)} کی نمازوں کا خلاصہ"
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = bg(C.col("#8AD3B0"), 14)
        bar.setPadding(dp(12), dp(10), dp(12), dp(10))
        bar.addView(tv("🗓", 18f, C.DARK), lp(WRAP, WRAP).margins(0, 0, dp(8), 0))
        bar.addView(tv(title, 15f, C.DARK, true, Gravity.START or Gravity.CENTER_VERTICAL), lp(0, WRAP, 1f))
        content.addView(bar, lp(MATCH, WRAP).margins(dp(4), dp(2), dp(4), dp(6)))

        content.addView(tiles(), lp(MATCH, WRAP).margins(dp(4), 0, dp(4), dp(6)))
        content.addView(stats(w), lp(MATCH, WRAP).margins(dp(4), 0, dp(4), dp(6)))
        content.addView(detailsBar(), lp(MATCH, WRAP).margins(dp(4), dp(4), dp(4), 0))
        content.addView(table(), lp(MATCH, WRAP).margins(dp(4), dp(4), dp(4), 0))

        val hint = tv("وقت، پڑھنے کا وقت، حالت اور نوٹ پر ٹیپ کر کے تبدیل کریں۔ رنگین کارڈ پر ٹیپ = مکمل/باقی، دیر تک دبائیں = مزید اختیارات۔", 10f, C.MUTED)
        content.addView(hint, lp(MATCH, WRAP).margins(dp(8), dp(4), dp(8), dp(6)))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(messageCard(), lp(0, MATCH, 1f).margins(dp(3), 0, dp(3), 0))
        row.addView(chartCard(w), lp(0, MATCH, 1.15f).margins(dp(3), 0, dp(3), 0))
        content.addView(row, lp(MATCH, WRAP).margins(dp(1), dp(4), dp(1), 0))
    }

    private fun tiles(): View {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.HORIZONTAL
        wrap.layoutDirection = View.LAYOUT_DIRECTION_LTR
        wrap.background = bg(C.col("#F6FAF1"), 16, C.BORDER, 1)
        wrap.setPadding(dp(3), dp(6), dp(3), dp(6))
        for (i in 0 until 5) {
            val st = Store.prayerStatus(this, key, i)
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER_HORIZONTAL
            card.background = bg(light[i], 14, accent[i], 1)

            val top = LinearLayout(this)
            top.orientation = LinearLayout.VERTICAL
            top.gravity = Gravity.CENTER
            top.background = topBg(accent[i], 14)
            top.setPadding(dp(2), dp(8), dp(2), dp(8))
            top.addView(tv(icons[i], 22f, Color.WHITE))
            top.addView(tv(Dates.prayers[i], 15f, Color.WHITE, true))
            card.addView(top, lp(MATCH, WRAP))

            card.addView(tv(stTile[st], 11f, C.TEXT), lp(WRAP, WRAP).margins(0, dp(8), 0, 0))
            card.addView(tv(if (st == 1 || st == 2) "1/1" else "0/1", 16f, C.DARK, true))
            card.addView(statusDot(st), lp(dp(24), dp(24)).margins(0, dp(4), 0, dp(8)))

            card.setOnClickListener { setStatus(i, if (st == 1 || st == 2) 0 else 1) }
            card.setOnLongClickListener { statusDialog(i); true }
            wrap.addView(card, lp(0, WRAP, 1f).margins(dp(3), 0, dp(3), 0))
        }
        return wrap
    }

    private fun statTile(icon: String, iconBg: Int, round: Boolean, label: String, v: Int, unit: String, color: Int, weight: Float): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.background = bg(C.CARD, 14, C.BORDER, 1)
        c.setPadding(dp(6), dp(8), dp(6), dp(8))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.addView(tv(label, 11f, C.DARK, true))
        col.addView(tv(v.toString(), 20f, color, true))
        col.addView(tv(unit, 9f, C.MUTED))
        c.addView(col, lp(0, WRAP, 1f))
        val ic = tv(icon, 14f, Color.WHITE, true)
        ic.background = if (round) oval(iconBg) else bg(iconBg, 8)
        c.addView(ic, lp(dp(28), dp(28)))
        statWeights.add(weight)
        return c
    }

    private val statWeights = ArrayList<Float>()

    private fun stats(w: Week): View {
        statWeights.clear()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val tl = listOf(
            statTile("🕌", C.DARK, false, "کل نمازیں", w.total, "${w.elapsed} دن میں", C.DARK, 1.15f),
            statTile("✔", C.GREEN, true, "مکمل", w.complete, "دن", C.GREEN, 1f),
            statTile("⏱", C.ORANGE, true, "قضا", w.qazaDays, "دن", C.ORANGE, 1f),
            statTile("✖", C.RED, true, "چھوٹی", w.missedDays, "دن", C.RED, 1f)
        )
        for (i in tl.indices) row.addView(tl[i], lp(0, WRAP, statWeights[i]).margins(dp(2), 0, dp(2), 0))
        return row
    }

    private fun detailsBar(): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = bg(C.DARK, 14)
        bar.setPadding(dp(10), dp(8), dp(10), dp(8))
        bar.addView(tv("🗓  روزانہ کی تفصیل", 14f, Color.WHITE, true, Gravity.START or Gravity.CENTER_VERTICAL), lp(0, WRAP, 1f))

        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = bg(C.col("#14573F"), 20, C.GOLD, 1)
        pill.setPadding(dp(4), dp(2), dp(4), dp(2))

        val prev = tv("›", 22f, Color.WHITE, true)
        prev.setPadding(dp(8), 0, dp(8), 0)
        prev.setOnClickListener { sel = sel.minusDays(1); refresh() }

        val canNext = sel.isBefore(LocalDate.now())
        val next = tv("‹", 22f, Color.WHITE, true)
        next.setPadding(dp(8), 0, dp(8), 0)
        next.alpha = if (canNext) 1f else 0.35f
        next.setOnClickListener {
            if (canNext) { sel = sel.plusDays(1); refresh() } else toast("آنے والے دن کی نمازیں درج نہیں ہو سکتیں")
        }

        val dt = tv("${Dates.greg(sel)} (${Dates.urduDay(sel)})", 11f, Color.WHITE, true)
        dt.setPadding(dp(4), dp(4), dp(4), dp(4))
        dt.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                sel = LocalDate.of(y, m + 1, d)
                refresh()
            }, sel.year, sel.monthValue - 1, sel.dayOfMonth).also {
                it.datePicker.maxDate = System.currentTimeMillis()
            }.show()
        }
        pill.addView(prev)
        pill.addView(dt)
        pill.addView(next)
        bar.addView(pill, lp(WRAP, WRAP))
        return bar
    }

    private val cw = floatArrayOf(1.35f, 1.05f, 1.1f, 1.0f, 0.75f, 1.5f)

    private fun cell(i: Int, v: View): View {
        val box = LinearLayout(this)
        box.gravity = Gravity.CENTER
        box.addView(v)
        box.layoutParams = LinearLayout.LayoutParams(0, WRAP, cw[i])
        return box
    }

    private fun table(): View {
        val tbl = LinearLayout(this)
        tbl.orientation = LinearLayout.VERTICAL
        tbl.background = bg(C.SURFACE, 12, C.BORDER, 1)

        val heads = arrayOf("نماز", "وقت", "پڑھنے کا وقت", "حالت", "رکعات", "نوٹ")
        val hr = LinearLayout(this)
        hr.orientation = LinearLayout.HORIZONTAL
        hr.setBackgroundColor(C.col("#EAF2E3"))
        hr.setPadding(dp(2), dp(9), dp(2), dp(9))
        for (i in heads.indices) hr.addView(cell(i, tv(heads[i], 11f, C.DARK, true)))
        tbl.addView(hr, lp(MATCH, WRAP))

        for (i in 0 until 5) {
            val st = Store.prayerStatus(this, key, i)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(2), dp(8), dp(2), dp(8))

            // نماز
            val nm = LinearLayout(this)
            nm.orientation = LinearLayout.HORIZONTAL
            nm.gravity = Gravity.CENTER_VERTICAL
            val ic = tv(icons[i], 12f, Color.WHITE)
            ic.background = oval(accent[i])
            nm.addView(ic, lp(dp(26), dp(26)))
            nm.addView(tv(Dates.prayers[i], 13f, C.DARK, true), lp(WRAP, WRAP).margins(0, 0, dp(4), 0))
            row.addView(cell(0, nm))

            // وقت (editable)
            val tm = tv(Dates.fmtTime(Store.prayerTime(this, i)), 10.5f, C.TEXT)
            tm.setPadding(dp(2), dp(4), dp(2), dp(4))
            tm.setOnClickListener {
                pickTime(Store.prayerTime(this, i)) { m -> Store.setPrayerTime(this, i, m); refresh() }
            }
            row.addView(cell(1, tm))

            // پڑھنے کا وقت
            val pt = Store.prayedTime(this, key, i)
            val done = st == 1 || st == 2
            val ptv = tv(if (done && pt >= 0) Dates.fmtTime(pt) else "-", 10.5f, C.TEXT)
            ptv.setPadding(dp(2), dp(4), dp(2), dp(4))
            ptv.setOnClickListener {
                if (!done) toast("پہلے حالت مکمل یا قضا کریں")
                else pickTime(if (pt >= 0) pt else Store.prayerTime(this, i)) { m ->
                    Store.setPrayedTime(this, key, i, m); refresh()
                }
            }
            row.addView(cell(2, ptv))

            // حالت
            val chipColor = when (st) {
                1 -> C.GREEN
                2 -> C.ORANGE
                3 -> C.RED
                else -> C.col("#9AA39D")
            }
            val chip = tv(stLabel[st], 11f, Color.WHITE, true)
            chip.background = bg(chipColor, 12)
            chip.setPadding(dp(10), dp(4), dp(10), dp(4))
            chip.setOnClickListener { statusDialog(i) }
            row.addView(cell(3, chip))

            // رکعات
            row.addView(cell(4, tv(rakats[i].toString(), 12f, C.TEXT)))

            // نوٹ
            val saved = Store.prayerNote(this, key, i)
            val nt = tv(if (saved.isNotEmpty()) saved else defaultNote(st), 10.5f, C.TEXT)
            nt.maxLines = 2
            nt.setPadding(dp(3), dp(4), dp(3), dp(4))
            nt.setOnClickListener { noteDialog(i) }
            row.addView(cell(5, nt))

            tbl.addView(row, lp(MATCH, WRAP))
            if (i < 4) {
                val dv = View(this)
                dv.setBackgroundColor(C.col("#EDE6C8"))
                tbl.addView(dv, lp(MATCH, dp(1)))
            }
        }
        return tbl
    }

    private fun chartCard(w: Week): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(C.CARD, 14, C.BORDER, 1)

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.background = topBg(C.col("#1E6B4A"), 14)
        head.setPadding(dp(6), dp(6), dp(6), dp(6))
        val weekTxt = if (sel.minusDays((sel.dayOfWeek.value - 1).toLong()) == LocalDate.now().minusDays((LocalDate.now().dayOfWeek.value - 1).toLong())) "اس ہفتے" else "منتخب ہفتہ"
        head.addView(tv("نمازوں کی ادائیگی ($weekTxt)", 10f, Color.WHITE, true, Gravity.START or Gravity.CENTER_VERTICAL), lp(0, WRAP, 1f))
        val pct = if (w.elapsed == 0) 0 else Math.round(w.total * 100f / (w.elapsed * 5))
        val badge = tv("$pct%", 10f, Color.WHITE, true)
        badge.background = bg(C.col("#12A05A"), 10)
        badge.setPadding(dp(6), dp(2), dp(6), dp(2))
        head.addView(badge)
        card.addView(head, lp(MATCH, WRAP))

        val chart = LinearLayout(this)
        chart.orientation = LinearLayout.HORIZONTAL
        chart.layoutDirection = View.LAYOUT_DIRECTION_LTR
        chart.setPadding(dp(4), dp(8), dp(4), dp(6))

        val maxV = if (w.elapsed < 1) 1 else w.elapsed
        val axis = LinearLayout(this)
        axis.orientation = LinearLayout.VERTICAL
        axis.addView(tv(maxV.toString(), 9f, C.MUTED), lp(WRAP, dp(90) - dp(10)))
        axis.addView(tv("0", 9f, C.MUTED), lp(WRAP, dp(10)))
        chart.addView(axis, lp(dp(14), WRAP))

        for (i in 0 until 5) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            val area = LinearLayout(this)
            area.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            val h = if (w.per[i] == 0) dp(2) else (dp(80) * w.per[i] / maxV).coerceAtLeast(dp(4))
            val b = View(this)
            b.background = topBg(accent[i], 3)
            b.setOnClickListener { toast("${Dates.prayers[i]}: ${w.per[i]}/${w.elapsed} دن") }
            area.addView(b, lp(dp(14), h))
            col.addView(area, lp(MATCH, dp(90)))
            col.addView(tv(Dates.prayers[i], 9f, C.DARK, true))
            col.addView(tv("${w.per[i]}/${w.elapsed}", 8f, C.MUTED))
            chart.addView(col, lp(0, WRAP, 1f))
        }
        card.addView(chart, lp(MATCH, WRAP))
        return card
    }

    private fun messageCard(): View {
        if (msgIdx < 0) msgIdx = sel.dayOfYear % msgs.size
        val m = msgs[msgIdx % msgs.size]
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.gravity = Gravity.CENTER
        card.background = bg(C.col("#EEF5E6"), 14, C.col("#CFE3BC"), 1)
        card.setPadding(dp(8), dp(10), dp(8), dp(10))
        card.addView(tv("نماز کا پیغام", 13f, C.DARK, true))
        card.addView(tv("“${m[0]}”", 12f, C.TEXT), lp(WRAP, WRAP).margins(0, dp(8), 0, dp(6)))
        card.addView(tv(m[1], 10f, C.MUTED))
        card.addView(tv("نیا پیغام ↻", 10f, C.GREEN, true), lp(WRAP, WRAP).margins(0, dp(6), 0, 0))
        card.setOnClickListener { msgIdx = (msgIdx + 1) % msgs.size; refresh() }
        return card
    }
}
