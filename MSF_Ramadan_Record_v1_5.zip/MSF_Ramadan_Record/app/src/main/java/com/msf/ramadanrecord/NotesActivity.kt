package com.msf.ramadanrecord

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate
import java.time.LocalTime

class NotesActivity : BaseActivity() {

    private class Cat(val name: String, val title: String, val icon: String, val bgC: Int, val accent: Int)

    // 0 fast, 1 qaza, 2 prayer, 3 sehri, 4 iftar, 5 quran, 6 other
    private val cats = listOf(
        Cat("روزہ", "روزے کا نوٹ", "📅", C.col("#E6F2DD"), C.col("#2E8B3A")),
        Cat("قضا روزہ", "قضا روزہ کا نوٹ", "⏱", C.col("#DDF3F0"), C.col("#12907A")),
        Cat("نماز", "نماز کا نوٹ", "🕌", C.col("#E1EFFB"), C.col("#1F6FD0")),
        Cat("سحری", "سحری کا نوٹ", "🍲", C.col("#E3F4EA"), C.col("#1E8E6A")),
        Cat("افطار", "افطار کا نوٹ", "🌴", C.col("#FFF1DC"), C.col("#E8921A")),
        Cat("قرآن پاک", "قرآن پاک کا نوٹ", "📖", C.col("#EDE3F8"), C.col("#7A3BA8")),
        Cat("دیگر", "ذاتی نوٹ", "❤", C.col("#FCE3E8"), C.col("#D9376E"))
    )

    // tabs: label, icon, categories included
    private val tabs = listOf(
        Triple("تمام نوٹس", "✏️", listOf(0, 1, 2, 3, 4, 5, 6)),
        Triple("روزہ", "📅", listOf(0, 1)),
        Triple("نماز", "🕌", listOf(2)),
        Triple("سحری / افطار", "🍲", listOf(3, 4)),
        Triple("قرآن پاک", "📖", listOf(5)),
        Triple("دیگر", "⚙️", listOf(6))
    )
    private var tab = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val addBtn = tv("＋  نیا نوٹ شامل کریں", 15f, Color.WHITE, true)
        addBtn.background = bg(C.col("#0C5A3A"), 24, C.GOLD, 2)
        addBtn.setPadding(dp(24), dp(11), dp(24), dp(11))
        addBtn.setOnClickListener { editNote(-1) }
        val footer = LinearLayout(this)
        footer.gravity = Gravity.CENTER
        footer.setBackgroundColor(C.BG)
        footer.setPadding(0, dp(6), 0, dp(6))
        footer.addView(addBtn, lp(WRAP, WRAP))

        val content = heroScreen("ذاتی نوٹس", "اپنی سوچیں، اپنے احساسات اور اہم باتیں نوٹ کریں۔", 9, footer)
        val all = Store.notes(this)

        // ---- category tabs ----
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in tabs.indices) {
            val t = tabs[i]
            val count = all.count { it.cat in t.third }
            val sel = i == tab
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(if (sel) C.col("#0C5A3A") else C.col("#F1F5EC"), 14, C.BORDER, 1)
            c.setPadding(dp(4), dp(8), dp(4), dp(8))
            c.addView(tv(t.second, 20f, if (sel) Color.WHITE else C.DARK))
            c.addView(tv(t.first, 11f, if (sel) Color.WHITE else C.DARK, true).also { it.setPadding(0, dp(2), 0, dp(2)) })
            val badge = tv(count.toString(), 11f, if (sel) C.col("#0C5A3A") else Color.WHITE, true)
            badge.background = oval(if (sel) Color.WHITE else C.col("#2E8B3A"))
            c.addView(badge, lp(dp(22), dp(22)))
            c.setOnClickListener {
                tab = i
                render()
            }
            row.addView(c, lp(dp(84), WRAP).margins(dp(3), 0, dp(3), 0))
        }
        hs.addView(row)
        content.addView(hs, lp(MATCH, WRAP))

        // ---- list ----
        val shown = all.withIndex()
            .filter { it.value.cat in tabs[tab].third }
            .sortedWith(compareByDescending<IndexedValue<Note>> { it.value.date }.thenByDescending { it.value.min })

        if (shown.isEmpty()) {
            val e = card(content)
            e.addView(tv("اس زمرے میں ابھی کوئی نوٹ نہیں۔ نیچے والے بٹن سے نیا نوٹ شامل کریں۔", 14f, C.MUTED))
        }
        for (iv in shown) content.addView(noteCard(iv.index, iv.value), lp(MATCH, WRAP).margins(dp(2), dp(5), dp(2), dp(5)))
    }

    private fun noteCard(index: Int, n: Note): View {
        val cat = cats[n.cat.coerceIn(0, 6)]
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = bg(cat.bgC, 16, cat.accent, 1)
        row.setPadding(dp(10), dp(10), dp(10), dp(10))

        val ic = tv(cat.icon, 22f, Color.WHITE)
        ic.background = oval(cat.accent)
        row.addView(ic, lp(dp(50), dp(50)))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(dp(10), 0, dp(10), 0)
        mid.addView(tv(cat.title, 15f, cat.accent, true, Gravity.START))
        val body = tv(n.text, 13f, C.TEXT, false, Gravity.START)
        body.maxLines = 3
        mid.addView(body)
        val date = try { LocalDate.parse(n.date) } catch (e: Exception) { LocalDate.now() }
        var meta = "📅 ${Dates.greg(date)} (${Dates.urduDay(date)})"
        if (n.min >= 0) meta += "   🕒 ${Dates.fmtTime(n.min)}"
        mid.addView(tv(meta, 11f, C.MUTED, false, Gravity.START).also { it.setPadding(0, dp(4), 0, 0) })
        row.addView(mid, lp(0, WRAP, 1f))

        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER
        side.addView(pill(cat.name, cat.accent, 11f))
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL
        val ed = tv("✏️", 15f, Color.WHITE)
        ed.background = bg(C.GREEN, 8)
        ed.setOnClickListener { editNote(index) }
        val del = tv("🗑", 15f, Color.WHITE)
        del.background = bg(C.RED, 8)
        del.setOnClickListener { confirmDelete(index) }
        btns.addView(ed, lp(dp(34), dp(34)).margins(dp(2), 0, dp(2), 0))
        btns.addView(del, lp(dp(34), dp(34)).margins(dp(2), 0, dp(2), 0))
        side.addView(btns, lp(WRAP, WRAP).margins(0, dp(8), 0, 0))
        row.addView(side, lp(WRAP, WRAP))

        row.setOnClickListener { editNote(index) }
        return row
    }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this)
            .setMessage("یہ نوٹ حذف کریں؟")
            .setPositiveButton("حذف کریں") { _, _ ->
                val l = Store.notes(this)
                if (index in l.indices) {
                    l.removeAt(index)
                    Store.saveNotes(this, l)
                }
                render()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun editNote(index: Int) {
        val list = Store.notes(this)
        val old: Note? = if (index in list.indices) list[index] else null
        var date: LocalDate = if (old != null) LocalDate.parse(old.date) else LocalDate.now()
        val nowT = LocalTime.now()
        var minutes: Int = if (old != null) old.min else nowT.hour * 60 + nowT.minute

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        box.addView(fieldLabel("نوٹ کی قسم"))
        val defaultCat = if (old != null) old.cat else {
            val g = tabs[tab].third
            if (g.size == 1 || tab > 0) g[0] else 6
        }
        val catSp = spinnerOf(Array(cats.size) { cats[it].name }, defaultCat.coerceIn(0, 6))
        box.addView(catSp, lp(MATCH, WRAP))

        box.addView(fieldLabel("تاریخ"))
        val dateBtn = tv(Dates.greg(date), 14f, Color.WHITE, true)
        dateBtn.background = bg(C.BLUE, 10)
        dateBtn.setPadding(dp(12), dp(10), dp(12), dp(10))
        dateBtn.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                date = LocalDate.of(y, m + 1, d)
                dateBtn.text = Dates.greg(date)
            }, date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        box.addView(dateBtn, lp(MATCH, WRAP))

        box.addView(fieldLabel("وقت"))
        val timeBtn = tv(if (minutes >= 0) Dates.fmtTime(minutes) else "وقت منتخب کریں", 14f, Color.WHITE, true)
        timeBtn.background = bg(C.ORANGE, 10)
        timeBtn.setPadding(dp(12), dp(10), dp(12), dp(10))
        timeBtn.setOnClickListener {
            val h0 = if (minutes >= 0) minutes / 60 else nowT.hour
            val m0 = if (minutes >= 0) minutes % 60 else nowT.minute
            TimePickerDialog(this, { _, h, m ->
                minutes = h * 60 + m
                timeBtn.text = Dates.fmtTime(minutes)
            }, h0, m0, false).show()
        }
        box.addView(timeBtn, lp(MATCH, WRAP))

        box.addView(fieldLabel("نوٹ"))
        val edit = EditText(this)
        edit.minLines = 4
        edit.gravity = Gravity.TOP or Gravity.START
        edit.hint = "یہاں نوٹ لکھیں"
        if (old != null) edit.setText(old.text)
        box.addView(edit, lp(MATCH, WRAP))

        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)

        val b = AlertDialog.Builder(this)
            .setTitle(if (old != null) "نوٹ میں ترمیم" else "نیا نوٹ")
            .setView(scroll)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                val text = edit.text.toString().trim()
                if (text.isEmpty()) {
                    toast("پہلے نوٹ لکھیں")
                } else {
                    val rec = Note(text, date.toString(), catSp.selectedItemPosition, minutes)
                    if (old != null) list[index] = rec else list.add(0, rec)
                    Store.saveNotes(this, list)
                    render()
                }
            }
            .setNegativeButton("منسوخ", null)
        if (old != null) {
            b.setNeutralButton("حذف") { _, _ ->
                list.removeAt(index)
                Store.saveNotes(this, list)
                render()
            }
        }
        b.show()
    }
}
