package com.msf.ramadanrecord

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        C.dark = Store.darkMode(this)
        Fonts.init(this)
        Reminders.scheduleAll(this)
    }
}
