package com.msf.ramadanrecord

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

object C {
    /** true when dark theme is active (set from BaseActivity before any screen is built) */
    @JvmField var dark: Boolean = false

    val DARK = Color.parseColor("#0B3D2E")
    val GREEN = Color.parseColor("#1E7A3C")
    val GOLD = Color.parseColor("#D4A72C")
    val ORANGE = Color.parseColor("#E8921A")
    val PURPLE = Color.parseColor("#7A3BA8")
    val BLUE = Color.parseColor("#1F6FD0")
    val TEAL = Color.parseColor("#12907A")
    val RED = Color.parseColor("#D9434E")

    val BG: Int get() = Color.parseColor(if (dark) "#0F1A15" else "#FFF9E8")
    val CARD: Int get() = Color.parseColor(if (dark) "#16241D" else "#FFFDF5")
    val BORDER: Int get() = Color.parseColor(if (dark) "#2A4034" else "#E6DDB8")
    val TEXT: Int get() = Color.parseColor(if (dark) "#E8EFE9" else "#1F2A24")
    val MUTED: Int get() = Color.parseColor(if (dark) "#9BAAA1" else "#6B746E")
    val HIGHLIGHT: Int get() = Color.parseColor(if (dark) "#3A3320" else "#FFF1C2")
    val GRAY: Int get() = Color.parseColor(if (dark) "#24302A" else "#E9ECE6")
    val SURFACE: Int get() = if (dark) Color.parseColor("#16241D") else Color.WHITE

    /** Parses a colour; in dark mode very light colours are darkened so cards/tables stay readable. */
    fun col(hex: String): Int {
        val c = Color.parseColor(hex)
        if (!dark || hex.equals("#F3E3A5", true)) return c
        val lum = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
        if (lum < 0.8) return c
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[1] = minOf(hsv[1], 0.45f)
        hsv[2] = 0.17f + hsv[2] * 0.08f
        return Color.HSVToColor(hsv)
    }
}

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.bg(color: Int, radiusDp: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadius = dp(radiusDp).toFloat()
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.oval(color: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
    val g = GradientDrawable()
    g.shape = GradientDrawable.OVAL
    g.setColor(color)
    if (strokeDp > 0) g.setStroke(dp(strokeDp), strokeColor)
    return g
}

fun Context.tv(
    text: String,
    sizeSp: Float = 14f,
    color: Int = C.TEXT,
    bold: Boolean = false,
    gravity: Int = Gravity.CENTER
): TextView {
    val t = TextView(this)
    t.text = text
    t.textSize = sizeSp
    t.setTextColor(color)
    Fonts.active?.let { t.typeface = it }
    if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
    t.gravity = gravity
    return t
}

fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

fun LinearLayout.LayoutParams.margins(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams {
    setMargins(l, t, r, b)
    return this
}

fun Activity.buildNav(selected: Int): View {
    val sv = HorizontalScrollView(this)
    sv.isHorizontalScrollBarEnabled = false
    sv.layoutDirection = View.LAYOUT_DIRECTION_LTR
    sv.setBackgroundColor(C.DARK)
    val nav = LinearLayout(this)
    nav.orientation = LinearLayout.HORIZONTAL
    nav.layoutDirection = View.LAYOUT_DIRECTION_LTR
    nav.setPadding(dp(4), dp(6), dp(4), dp(6))
    val items = listOf<Triple<String, String, Class<*>>>(
        Triple("🏠", "ہوم", HomeActivity::class.java),
        Triple("🍲", "سحری و افطاری", TimesActivity::class.java),
        Triple("📅", "روزے", CalendarActivity::class.java),
        Triple("🕌", "فرض روزے", FastsActivity::class.java),
        Triple("🌙", "قضا روزے", QazaActivity::class.java),
        Triple("📆", "نفلی روزے", NafliActivity::class.java),
        Triple("🕋", "نمازیں", PrayersActivity::class.java),
        Triple("📖", "قرآن پاک", QuranActivity::class.java),
        Triple("📊", "رپورٹس", ReportsActivity::class.java),
        Triple("📝", "نوٹس", NotesActivity::class.java),
        Triple("⚙️", "سیٹنگز", SettingsActivity::class.java)
    )
    for (i in items.indices) {
        val item = items[i]
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setPadding(dp(2), dp(6), dp(2), dp(6))
        val active = i == selected
        if (active) col.background = bg(Color.parseColor("#14573F"), 14, C.GOLD, 2)
        col.addView(tv(item.first, 20f, Color.WHITE))
        col.addView(tv(item.second, 11f, if (active) C.ORANGE else Color.WHITE, active))
        col.setOnClickListener {
            if (i != selected) {
                val target = item.third
                val intent = Intent(this, target)
                if (target == HomeActivity::class.java) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    startActivity(intent)
                } else {
                    startActivity(intent)
                    if (this !is HomeActivity) finish()
                }
            }
        }
        nav.addView(col, lp(dp(74), WRAP).margins(dp(2), 0, dp(2), 0))
    }
    sv.addView(nav, FrameLayout.LayoutParams(WRAP, WRAP))
    if (selected > 1) sv.post { sv.scrollTo(maxOf(0, (selected - 1) * dp(78)), 0) }
    return sv
}
