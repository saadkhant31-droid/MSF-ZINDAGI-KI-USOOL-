package com.msf.ramadanrecord

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate

class NafliActivity : BaseActivity() {

    private var filter = -1  // -1 all, 0..4 type

    private val typeLabels = arrayOf("پیر کا روزہ", "جمعرات کا روزہ", "ایام بیض کا روزہ", "شوال کے 6 روزے", "دیگر نفلی روزہ")
    private val statusLabels = arrayOf("رکھا", "توڑا", "نہیں رکھا")
    private val reasonLabels = arrayOf("کوئی نہیں", "جان بوجھ کر", "بیماری کی وجہ سے", "دیگر وجہ")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val content = heroScreen("نفلی روزے", "اللہ کے لیے نفل روزے، دل کو سکون دیتے ہیں", 5)
        val all = Store.naflis(this)
        val shown = all.withIndex()
            .filter { filter < 0 || it.value.type == filter }
            .sortedByDescending { it.value.date }

        content.addView(chips(), lp(MATCH, WRAP))
        content.addView(barTitle("📊 نفلی روزوں کا خلاصہ", null), lp(MATCH, WRAP).margins(dp(4), dp(10), dp(4), 0))
        content.addView(summary(shown.map { it.value }), lp(MATCH, WRAP).margins(0, dp(6), 0, 0))

        val addBtn = tv("＋ نیا ریکارڈ شامل کریں", 12f, Color.WHITE, true)
        addBtn.background = bg(C.GREEN, 18, C.GOLD, 1)
        addBtn.setPadding(dp(12), dp(7), dp(12), dp(7))
        addBtn.setOnClickListener { editDialog(-1) }
        content.addView(barTitle("📅 روزوں کا ریکارڈ", addBtn), lp(MATCH, WRAP).margins(dp(4), dp(10), dp(4), 0))

        content.addView(table(shown), lp(MATCH, WRAP).margins(dp(4), dp(6), dp(4), 0))

        val note = card(content, C.col("#E8F2DC"))
        note.addView(tv("نوٹ: نفلی روزوں کے توڑنے اور ان کی قضا کے احکام فقہی صورتِ حال کے مطابق مختلف ہو سکتے ہیں، اس لیے ایپ میں انہیں فرض قضا روزوں میں شامل نہیں کیا جاتا۔", 12f, C.TEXT, false, Gravity.START))
    }

    // ---------- top chips ----------
    private fun chips(): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val defs = listOf("🕌" to "نفلی روزے", "📅" to "پیر کے روزے", "📅" to "جمعرات کے روزے", "🌙" to "ایام بیض کے روزے", "📅" to "شوال کے روزے", "⋯" to "دیگر نفلی روزے")
        for (i in defs.indices) {
            val sel = (i - 1) == filter
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(if (sel) C.DARK else C.col("#E8F2DC"), 14, C.BORDER, 1)
            c.addView(tv(defs[i].first, 22f, if (sel) Color.WHITE else C.DARK, true))
            val l = tv(defs[i].second, 11f, if (sel) Color.WHITE else C.DARK, true)
            l.setPadding(dp(4), dp(4), dp(4), 0)
            c.addView(l)
            c.setOnClickListener {
                filter = i - 1
                render()
            }
            row.addView(c, lp(dp(96), dp(82)).margins(dp(4), 0, dp(4), 0))
        }
        hs.addView(row)
        return hs
    }

    private fun barTitle(title: String, trailing: View?): View {
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = bg(C.DARK, 14)
        bar.setPadding(dp(14), dp(10), dp(14), dp(10))
        bar.addView(tv(title, 15f, Color.WHITE, true, Gravity.START or Gravity.CENTER_VERTICAL), lp(0, WRAP, 1f))
        if (trailing != null) bar.addView(trailing, lp(WRAP, WRAP))
        return bar
    }

    // ---------- summary ----------
    private fun summary(list: List<NafliRec>): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun add(icon: String, label: String, v: Int, color: Int) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(color, 14)
            c.setPadding(dp(2), dp(10), dp(2), dp(10))
            c.addView(tv(icon, 22f, Color.WHITE))
            val l = tv(label, 10f, Color.WHITE)
            l.minLines = 2
            l.maxLines = 2
            c.addView(l)
            c.addView(tv(v.toString(), 24f, Color.WHITE, true))
            row.addView(c, lp(0, WRAP, 1f).margins(dp(3), 0, dp(3), 0))
        }
        add("➕", "بیماری کی وجہ سے توڑے", list.count { it.status == 1 && it.reason == 2 }, C.PURPLE)
        add("⚠", "جان بوجھ کر توڑے", list.count { it.status == 1 && it.reason == 1 }, C.ORANGE)
        add("✖", "توڑے گئے روزے", list.count { it.status == 1 }, C.RED)
        add("✔", "رکھے گئے روزے", list.count { it.status == 0 }, C.BLUE)
        add("✔", "کل نفلی روزے", list.size, C.col("#0C4A2C"))
        return row
    }

    // ---------- table ----------
    private val colW = intArrayOf(46, 56, 58, 48, 118, 76, 150, 74)  // dp, right-to-left

    private fun cell(w: Int, v: View): View {
        val box = LinearLayout(this)
        box.gravity = Gravity.CENTER
        box.addView(v)
        box.layoutParams = LinearLayout.LayoutParams(dp(w), WRAP)
        return box
    }

    private fun table(shown: List<IndexedValue<NafliRec>>): View {
        val hs = HorizontalScrollView(this)
        val tbl = LinearLayout(this)
        tbl.orientation = LinearLayout.VERTICAL
        tbl.background = bg(C.SURFACE, 12, C.BORDER, 1)
        hs.addView(tbl)

        val heads = arrayOf("تاریخ", "دن", "مہینہ", "سال", "نفلی روزے کی قسم", "روزہ رکھا؟", "وجہ / نوٹ", "عملیات")
        val hr = LinearLayout(this)
        hr.orientation = LinearLayout.HORIZONTAL
        hr.setBackgroundColor(C.col("#EAF2E3"))
        hr.setPadding(0, dp(10), 0, dp(10))
        for (i in heads.indices) hr.addView(cell(colW[i], tv(heads[i], 11f, C.DARK, true)))
        tbl.addView(hr)

        if (shown.isEmpty()) {
            tbl.addView(tv("ابھی کوئی ریکارڈ نہیں۔ \"نیا ریکارڈ شامل کریں\" دبائیں۔", 13f, C.MUTED).also { it.setPadding(dp(16), dp(20), dp(16), dp(20)) })
        }
        var n = 0
        for (iv in shown) {
            val r = iv.value
            val date = LocalDate.parse(r.date)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setBackgroundColor(if (n % 2 == 0) C.col("#F4F7EE") else C.SURFACE)
            row.setPadding(0, dp(8), 0, dp(8))
            n++

            row.addView(cell(colW[0], tv(date.dayOfMonth.toString(), 13f, C.TEXT)))
            row.addView(cell(colW[1], tv(Dates.urduDay(date), 12f, C.TEXT)))
            row.addView(cell(colW[2], tv(Dates.gMonths[date.monthValue - 1], 12f, C.TEXT)))
            row.addView(cell(colW[3], tv(date.year.toString(), 12f, C.TEXT)))
            row.addView(cell(colW[4], tv(typeLabels[r.type.coerceIn(0, 4)], 12f, C.TEXT)))

            val st = tv(statusLabels[r.status.coerceIn(0, 2)], 12f, Color.WHITE, true)
            st.setPadding(dp(12), dp(4), dp(12), dp(4))
            val stColor = when (r.status) {
                0 -> C.GREEN
                1 -> C.RED
                else -> C.col("#7C8FA6")
            }
            st.background = bg(stColor, 8)
            row.addView(cell(colW[5], st))

            val noteText = if (r.note.isNotEmpty()) r.note else if (r.reason > 0) reasonLabels[r.reason.coerceIn(0, 3)] else "-"
            val nt = tv(noteText, 11f, C.TEXT, false, Gravity.START or Gravity.CENTER_VERTICAL)
            nt.maxLines = 3
            nt.layoutParams = LinearLayout.LayoutParams(dp(colW[6]), WRAP)
            nt.setPadding(dp(6), 0, dp(6), 0)
            row.addView(nt)

            val act = LinearLayout(this)
            act.orientation = LinearLayout.HORIZONTAL
            val ed = tv("✏️", 17f, Color.BLACK)
            ed.setPadding(dp(6), dp(4), dp(6), dp(4))
            ed.setOnClickListener { editDialog(iv.index) }
            val del = tv("🗑", 17f, Color.BLACK)
            del.setPadding(dp(6), dp(4), dp(6), dp(4))
            del.setOnClickListener { confirmDelete(iv.index) }
            act.addView(ed)
            act.addView(del)
            row.addView(cell(colW[7], act))

            tbl.addView(row)
        }
        return hs
    }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this)
            .setMessage("یہ ریکارڈ حذف کریں؟")
            .setPositiveButton("حذف کریں") { _, _ ->
                val list = Store.naflis(this)
                if (index in list.indices) {
                    list.removeAt(index)
                    Store.saveNaflis(this, list)
                }
                render()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    // ---------- add / edit dialog ----------
    private fun spinner(items: Array<String>, selected: Int): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.setSelection(selected)
        return s
    }

    private fun label(text: String): TextView {
        val t = tv(text, 12f, C.MUTED, true, Gravity.START)
        t.setPadding(0, dp(10), 0, dp(2))
        return t
    }

    private fun editDialog(index: Int) {
        val list = Store.naflis(this)
        val old: NafliRec? = if (index in list.indices) list[index] else null
        var date: LocalDate = if (old != null) LocalDate.parse(old.date) else LocalDate.now()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        box.addView(label("تاریخ"))
        val dateBtn = tv(Dates.greg(date), 14f, Color.WHITE, true)
        dateBtn.background = bg(C.BLUE, 10)
        dateBtn.setPadding(dp(12), dp(10), dp(12), dp(10))
        dateBtn.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                date = LocalDate.of(y, m + 1, d)
                dateBtn.text = Dates.greg(date)
            }, date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        box.addView(dateBtn, lp(MATCH, WRAP))

        box.addView(label("نفلی روزے کی قسم"))
        val typeSp = spinner(typeLabels, old?.type ?: (if (filter >= 0) filter else 0))
        box.addView(typeSp, lp(MATCH, WRAP))

        box.addView(label("روزہ رکھا؟"))
        val statusSp = spinner(statusLabels, old?.status ?: 0)
        box.addView(statusSp, lp(MATCH, WRAP))

        box.addView(label("توڑنے کی وجہ (صرف \"توڑا\" کی صورت میں)"))
        val reasonSp = spinner(reasonLabels, old?.reason ?: 0)
        box.addView(reasonSp, lp(MATCH, WRAP))

        box.addView(label("وجہ / نوٹ"))
        val noteEt = EditText(this)
        noteEt.setText(old?.note ?: "")
        noteEt.minLines = 2
        noteEt.textSize = 13f
        noteEt.gravity = Gravity.TOP or Gravity.START
        box.addView(noteEt, lp(MATCH, WRAP))

        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)

        AlertDialog.Builder(this)
            .setTitle(if (old != null) "ریکارڈ میں ترمیم" else "نیا ریکارڈ")
            .setView(scroll)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                val status = statusSp.selectedItemPosition
                val rec = NafliRec(
                    date.toString(),
                    typeSp.selectedItemPosition,
                    status,
                    if (status == 1) reasonSp.selectedItemPosition else 0,
                    noteEt.text.toString().trim()
                )
                if (old != null) list[index] = rec else list.add(rec)
                Store.saveNaflis(this, list)
                render()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }
}
