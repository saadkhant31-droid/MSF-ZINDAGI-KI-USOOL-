package com.msf.ramadanrecord

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream

class ProfileActivity : BaseActivity() {
    private lateinit var photoIv: ImageView

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) savePhoto(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun photoFile() = File(filesDir, "profile.jpg")

    private fun render() {
        val content = screen("میرا پروفائل", 10)

        photoIv = ImageView(this)
        photoIv.scaleType = ImageView.ScaleType.CENTER_CROP
        photoIv.background = oval(Color.parseColor("#0D4A35"), C.GOLD, 3)
        photoIv.clipToOutline = true
        photoIv.outlineProvider = ViewOutlineProvider.BACKGROUND
        photoIv.setOnClickListener { picker.launch("image/*") }
        val pl = lp(dp(120), dp(120)).margins(0, dp(14), 0, dp(6))
        pl.gravity = Gravity.CENTER_HORIZONTAL
        content.addView(photoIv, pl)
        loadPhoto()

        val change = tv("تصویر تبدیل کریں", 14f, C.GREEN, true)
        change.setPadding(dp(12), dp(8), dp(12), dp(8))
        change.setOnClickListener { picker.launch("image/*") }
        content.addView(change, lp(MATCH, WRAP))

        val remove = tv("تصویر ہٹائیں", 13f, C.RED, true)
        remove.setPadding(dp(12), dp(4), dp(12), dp(8))
        remove.setOnClickListener {
            photoFile().delete()
            Store.putStr(this, "profile_photo", "")
            loadPhoto()
            toast("تصویر ہٹا دی گئی")
        }
        content.addView(remove, lp(MATCH, WRAP))

        heading(content, "نام")
        val nameEt: EditText = inputField("اپنا نام لکھیں", Store.getStr(this, "profile_name"))
        content.addView(nameEt, lp(MATCH, WRAP).margins(dp(14), dp(4), dp(14), dp(4)))

        heading(content, "شہر")
        val cityEt: EditText = inputField("اپنا شہر لکھیں", Store.getStr(this, "profile_city"))
        content.addView(cityEt, lp(MATCH, WRAP).margins(dp(14), dp(4), dp(14), dp(4)))

        addButton(content, "محفوظ کریں", C.GREEN) {
            Store.putStr(this, "profile_name", nameEt.text.toString().trim())
            Store.putStr(this, "profile_city", cityEt.text.toString().trim())
            toast("پروفائل محفوظ ہو گیا")
            finish()
        }
    }

    private fun loadPhoto() {
        val f = photoFile()
        if (Store.getStr(this, "profile_photo").isNotEmpty() && f.exists()) {
            val bmp = BitmapFactory.decodeFile(f.path)
            if (bmp != null) {
                photoIv.setPadding(0, 0, 0, 0)
                photoIv.clearColorFilter()
                photoIv.setImageBitmap(bmp)
                return
            }
        }
        photoIv.setPadding(dp(30), dp(30), dp(30), dp(30))
        photoIv.setImageResource(R.drawable.ic_person)
    }

    private fun savePhoto(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) {
                toast("تصویر نہیں کھل سکی")
                return
            }
            FileOutputStream(photoFile()).use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            Store.putStr(this, "profile_photo", "profile.jpg")
            loadPhoto()
        } catch (e: Exception) {
            toast("تصویر محفوظ نہیں ہو سکی")
        }
    }
}
