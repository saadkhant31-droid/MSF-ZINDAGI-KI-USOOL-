package com.msf.ramadanrecord

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate
import java.time.temporal.ChronoUnit

class ReportsActivity : BaseActivity() {

    // 0 day, 1 three days, 2 week, 3 month, 4 year, 5 custom
    private var type = 0
    private var anchor: LocalDate = LocalDate.now()
    private var cFrom: LocalDate = LocalDate.now().minusDays(6)
    private var cTo: LocalDate = LocalDate.now()

    private val typeTitles = arrayOf(
        "ایک دن کی رپورٹ", "تین دن کی رپورٹ", "ایک ہفتے کی رپورٹ",
        "ایک مہینے کی رپورٹ", "ایک سال کی رپورٹ", "منتخب مدت کی رپورٹ"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    // ---------- period helpers ----------
    private fun range(): Pair<LocalDate, LocalDate> = when (type) {
        0 -> Pair(anchor, anchor)
        1 -> Pair(anchor.minusDays(2), anchor)
        2 -> Pair(anchor.minusDays(6), anchor)
        3 -> Pair(anchor.withDayOfMonth(1), anchor.withDayOfMonth(anchor.lengthOfMonth()))
        4 -> Pair(LocalDate.of(anchor.year, 1, 1), LocalDate.of(anchor.year, 12, 31))
        else -> Pair(cFrom, cTo)
    }

    private fun shift(dir: Int) {
        when (type) {
            0 -> anchor = anchor.plusDays(dir.toLong())
            1 -> anchor = anchor.plusDays(3L * dir)
            2 -> anchor = anchor.plusDays(7L * dir)
            3 -> anchor = anchor.plusMonths(dir.toLong())
            4 -> anchor = anchor.plusYears(dir.toLong())
            else -> {
                val span = ChronoUnit.DAYS.between(cFrom, cTo) + 1
                cFrom = cFrom.plusDays(span * dir)
                cTo = cTo.plusDays(span * dir)
            }
        }
        render()
    }

    private fun periodLabel(from: LocalDate, to: LocalDate): String = when (type) {
        0 -> "${Dates.greg(from)} (${Dates.urduDay(from)})"
        3 -> "${Dates.gMonths[from.monthValue - 1]} ${from.year}"
        4 -> from.year.toString()
        else -> if (from.year == to.year && from.monthValue == to.monthValue)
            "${from.dayOfMonth} - ${Dates.greg(to)}"
        else "${Dates.greg(from)} - ${Dates.greg(to)}"
    }

    private fun pickDate() {
        if (type == 5) {
            DatePickerDialog(this, { _, y, m, d ->
                val f = LocalDate.of(y, m + 1, d)
                DatePickerDialog(this, { _, y2, m2, d2 ->
                    val t = LocalDate.of(y2, m2 + 1, d2)
                    if (t.isBefore(f)) { cFrom = t; cTo = f } else { cFrom = f; cTo = t }
                    render()
                }, cTo.year, cTo.monthValue - 1, cTo.dayOfMonth).also { it.setTitle("آخری تاریخ") }.show()
            }, cFrom.year, cFrom.monthValue - 1, cFrom.dayOfMonth).also { it.setTitle("ابتدائی تاریخ") }.show()
        } else {
            DatePickerDialog(this, { _, y, m, d ->
                anchor = LocalDate.of(y, m + 1, d)
                render()
            }, anchor.year, anchor.monthValue - 1, anchor.dayOfMonth).show()
        }
    }

    // ---------- main render ----------
    private fun render() {
        val content = heroScreen("روزوں کی رپورٹس", "اپنی روزوں اور عبادات کی مکمل رپورٹ حاصل کریں", 8)

        content.addView(sectionBar("📅 رپورٹ کی اقسام", null), lp(MATCH, WRAP).margins(dp(4), dp(4), dp(4), 0))
        content.addView(typeGrid(), lp(MATCH, WRAP).margins(0, dp(6), 0, 0))

        val (from, to) = range()
        val nav = navPill(periodLabel(from, to))
        content.addView(sectionBar("📊 ${typeTitles[type]}", nav), lp(MATCH, WRAP).margins(dp(4), dp(10), dp(4), 0))

        if (type == 0) dayReport(content, from) else periodReport(content, from, to)
    }

    // ---------- type cards ----------
    private class TypeDef(val id: Int, val icon: String, val title: String, val desc: String, val bgC: Int, val accent: Int)

    private fun typeGrid(): View {
        val defs = listOf(
            TypeDef(2, "7", "ایک ہفتے کی رپورٹ", "سات دن کے روزوں اور عبادات کا حساب", C.col("#EBDFF8"), C.PURPLE),
            TypeDef(1, "3", "تین دن کی رپورٹ", "مسلسل تین دن کا ریکارڈ", C.col("#DCEBFB"), C.BLUE),
            TypeDef(0, "📅", "ایک دن کی رپورٹ", "کسی ایک منتخب تاریخ کا مکمل ریکارڈ", C.col("#DDF3DA"), C.col("#1E8E4A")),
            TypeDef(5, "✅", "اپنی تاریخ منتخب کریں", "اپنی مرضی کی مدت کی رپورٹ", C.col("#D9F1EE"), C.TEAL),
            TypeDef(4, "365", "ایک سال کی رپورٹ", "پورے سال کا ریکارڈ", C.col("#FBDADF"), C.RED),
            TypeDef(3, "🗓", "ایک مہینے کی رپورٹ", "کسی منتخب مہینے کی مکمل رپورٹ", C.col("#FDE9CF"), C.ORANGE)
        )
        val g = LinearLayout(this)
        g.orientation = LinearLayout.VERTICAL
        var i = 0
        while (i < defs.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                row.addView(typeCard(defs[i + k]), lp(0, WRAP, 1f).margins(dp(3), dp(3), dp(3), dp(3)))
            }
            g.addView(row, lp(MATCH, WRAP))
            i += 3
        }
        return g
    }

    private fun typeCard(d: TypeDef): View {
        val sel = d.id == type
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.START
        c.background = bg(d.bgC, 14, d.accent, if (sel) 3 else 1)
        c.setPadding(dp(8), dp(8), dp(8), dp(8))

        val ic = tv(d.icon, if (d.icon.length > 2) 12f else 17f, Color.WHITE, true)
        ic.background = oval(d.accent)
        c.addView(ic, lp(dp(40), dp(40)))
        c.addView(tv(d.title, 12f, C.col("#1F2A24"), true, Gravity.START).also { it.setPadding(0, dp(6), 0, 0) })
        val ds = tv(d.desc, 10f, C.MUTED, false, Gravity.START)
        ds.minLines = 3
        ds.maxLines = 3
        c.addView(ds)
        val ar = tv("›", 18f, Color.WHITE, true)
        ar.background = oval(d.accent)
        c.addView(ar, lp(dp(24), dp(24)).margins(0, dp(2), 0, 0))
        c.setOnClickListener {
            type = d.id
            if (type == 5) pickDate() else render()
        }
        return c
    }

    private fun navPill(label: String): View {
        val pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.background = bg(C.GREEN, 18, C.GOLD, 1)
        val prev = tv("›", 22f, Color.WHITE, true)
        prev.setPadding(dp(10), 0, dp(10), dp(2))
        prev.setOnClickListener { shift(-1) }
        val next = tv("‹", 22f, Color.WHITE, true)
        next.setPadding(dp(10), 0, dp(10), dp(2))
        next.setOnClickListener { shift(1) }
        val lab = tv("📅 $label", 12f, Color.WHITE, true)
        lab.setOnClickListener { pickDate() }
        lab.setPadding(dp(2), dp(6), dp(2), dp(6))
        pill.addView(prev)
        pill.addView(lab)
        pill.addView(next)
        return pill
    }

    // ---------- shared data helpers ----------
    private fun ramDay(d: LocalDate): Int {
        val n = ChronoUnit.DAYS.between(Store.startDate(this), d).toInt() + 1
        return if (n in 1..Store.totalDays(this)) n else 0
    }

    private fun dateList(from: LocalDate, to: LocalDate): List<LocalDate> {
        val out = ArrayList<LocalDate>()
        var d = from
        while (!d.isAfter(to)) {
            out.add(d)
            d = d.plusDays(1)
        }
        return out
    }

    // ---------- one day ----------
    private fun dayReport(content: LinearLayout, date: LocalDate) {
        val n = ramDay(date)
        val rec = if (n > 0) Store.fardRec(this, n) else null
        val fastText = when {
            n == 0 -> "—"
            rec != null && rec.kept -> "ہاں"
            rec != null && rec.recorded -> "نہیں"
            else -> "درج نہیں"
        }
        val sehri = Store.sehriRecorded(this, date)
        val iftar = Store.iftarRecorded(this, date)
        val prayers = Store.prayersOn(this, date)
        val paras = Store.parasBetween(this, date, date)
        val notes = Store.notes(this).filter { it.date == date.toString() }

        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun tile(icon: String, label: String, value: String, sub: String, color: Int, target: Class<*>) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(C.SURFACE, 14, C.BORDER, 1)
            c.setPadding(dp(4), dp(10), dp(4), dp(10))
            val ic = tv(icon, 20f, Color.WHITE)
            ic.background = oval(color)
            c.addView(ic, lp(dp(42), dp(42)))
            c.addView(tv(label, 11f, C.DARK, true).also { it.setPadding(0, dp(6), 0, 0) })
            val v = tv(value, 13f, color, true)
            v.maxLines = 3
            c.addView(v)
            if (sub.isNotEmpty()) c.addView(tv(sub, 10f, C.MUTED))
            c.setOnClickListener { go(target) }
            row.addView(c, lp(dp(92), dp(150)).margins(dp(3), dp(4), dp(3), dp(4)))
        }
        tile("📝", "نوٹ", if (notes.isEmpty()) "کوئی نوٹ نہیں" else notes[0].text.take(40), if (notes.size > 1) "کل ${notes.size} نوٹس" else "", C.PURPLE, NotesActivity::class.java)
        tile("📖", "قرآن پاک", if (paras > 0) "$paras پارے پڑھے" else "درج نہیں", "", C.TEAL, QuranActivity::class.java)
        tile("🕌", "نمازیں", "$prayers / 5", "ادا کیں", C.BLUE, PrayersActivity::class.java)
        tile("🍽", "افطار", if (iftar) "ہاں" else "درج نہیں", Dates.fmtTime(Store.iftar(this)), C.ORANGE, TimesActivity::class.java)
        tile("🍲", "سحری", if (sehri) "ہاں" else "درج نہیں", Dates.fmtTime(Store.sehri(this)), C.GREEN, TimesActivity::class.java)
        tile("🍴", "روزہ رکھا؟", fastText, "", C.col("#2E8B3A"), FastsActivity::class.java)
        tile("🌙", "رمضان کا دن", if (n > 0) n.toString() else "—", "", C.col("#0C4A2C"), CalendarActivity::class.java)
        hs.addView(row)
        content.addView(hs, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))

        val s = card(content, C.col("#E8F2DC"))
        val msg = if (n == 0) "یہ تاریخ رمضان کے فرض روزوں میں شامل نہیں ہے۔ دوسری عبادات کا ریکارڈ اوپر دیکھیں۔"
        else if (rec != null && rec.kept) "اس دن کا فرض روزہ رکھا گیا۔ الحمدللہ!"
        else if (rec != null && rec.recorded) "اس دن کا روزہ نہیں رکھا گیا، اسے قضا میں شامل کرنا نہ بھولیں۔"
        else "اس دن کا روزہ ابھی درج نہیں ہوا۔"
        s.addView(tv(msg, 13f, C.TEXT, false, Gravity.START))
    }

    // ---------- multi-day / month / year ----------
    private fun periodReport(content: LinearLayout, from: LocalDate, to: LocalDate) {
        val dates = dateList(from, to)
        val qazas = Store.qazas(this).filter { it.done }
        val naflis = Store.naflis(this).filter { it.status == 0 }

        var fardTotal = 0
        var kept = 0
        var missed = 0
        var qazaDone = 0
        var nafli = 0
        var prayers = 0
        var sehriDays = 0
        var iftarDays = 0
        val perDay = ArrayList<IntArray>()  // kept, missed, qaza, nafli
        for (d in dates) {
            val n = ramDay(d)
            var k = 0
            var m = 0
            if (n > 0) {
                fardTotal++
                val r = Store.fardRec(this, n)
                if (r.kept) k = 1 else if (r.recorded) m = 1
            }
            val q = qazas.count { it.date == d.toString() }
            val nf = naflis.count { it.date == d.toString() }
            kept += k; missed += m; qazaDone += q; nafli += nf
            prayers += Store.prayersOn(this, d)
            if (Store.sehriRecorded(this, d)) sehriDays++
            if (Store.iftarRecorded(this, d)) iftarDays++
            perDay.add(intArrayOf(k, m, q, nf))
        }
        val paras = Store.parasBetween(this, from, to)
        val notesCount = Store.notes(this).count {
            val d = LocalDate.parse(it.date)
            !d.isBefore(from) && !d.isAfter(to)
        }

        // tiles
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun add(icon: String, label: String, v: Int, color: Int, target: Class<*>) {
            val t = summaryTile(icon, label, v.toString(), color) { go(target) }
            row.addView(t, lp(dp(84), WRAP).margins(dp(3), dp(4), dp(3), dp(4)))
        }
        add("📖", "قرآن پاک کے پارے", paras, C.col("#0F5C63"), QuranActivity::class.java)
        add("🕌", "نمازیں", prayers, C.BLUE, PrayersActivity::class.java)
        add("⭐", "نفلی روزے", nafli, C.PURPLE, NafliActivity::class.java)
        add("🕒", "قضا روزے", qazaDone, C.ORANGE, QazaActivity::class.java)
        add("✖", "چھوڑے گئے روزے", missed, C.RED, FastsActivity::class.java)
        add("✔", "رکھے گئے روزے", kept, C.col("#1E8E6A"), FastsActivity::class.java)
        add("📅", "کل روزے", fardTotal, C.col("#1E7A3C"), FastsActivity::class.java)
        hs.addView(row)
        content.addView(hs, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))

        // chart
        val monthly = dates.size > 62
        val labels = ArrayList<String>()
        val bKept = ArrayList<Int>()
        val bMiss = ArrayList<Int>()
        val bQaza = ArrayList<Int>()
        val bNaf = ArrayList<Int>()
        if (!monthly) {
            for (i in dates.indices) {
                labels.add(if (dates.size <= 7) "${i + 1} دن" else dates[i].dayOfMonth.toString())
                bKept.add(perDay[i][0]); bMiss.add(perDay[i][1]); bQaza.add(perDay[i][2]); bNaf.add(perDay[i][3])
            }
        } else {
            var i = 0
            while (i < dates.size) {
                val key = dates[i].year * 100 + dates[i].monthValue
                var a = 0; var b = 0; var c2 = 0; var d2 = 0
                while (i < dates.size && dates[i].year * 100 + dates[i].monthValue == key) {
                    a += perDay[i][0]; b += perDay[i][1]; c2 += perDay[i][2]; d2 += perDay[i][3]
                    i++
                }
                labels.add((key % 100).toString())
                bKept.add(a); bMiss.add(b); bQaza.add(c2); bNaf.add(d2)
            }
        }
        val chartCard = card(content)
        chartCard.addView(tv("📊 روزوں کا گراف (${if (monthly) "ماہانہ" else if (dates.size <= 7) "${dates.size} دن" else "روزانہ"})", 13f, C.DARK, true, Gravity.START))
        val legend = LinearLayout(this)
        legend.orientation = LinearLayout.HORIZONTAL
        val lg = listOf("رکھے گئے" to C.col("#1E8E4A"), "چھوڑے گئے" to C.RED, "قضا" to C.ORANGE, "نفلی" to C.PURPLE)
        for (p in lg) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.HORIZONTAL
            item.gravity = Gravity.CENTER_VERTICAL
            val sq = View(this)
            sq.background = bg(p.second, 2)
            item.addView(sq, lp(dp(10), dp(10)))
            item.addView(tv(p.first, 10f, C.TEXT).also { it.setPadding(dp(4), 0, dp(4), 0) })
            legend.addView(item, lp(0, WRAP, 1f))
        }
        chartCard.addView(legend, lp(MATCH, WRAP).margins(0, dp(6), 0, dp(4)))
        val chart = BarChartView(this)
        chart.layoutDirection = View.LAYOUT_DIRECTION_LTR
        chart.labels = labels
        chart.series = listOf(
            Pair(C.col("#1E8E4A"), bKept.toIntArray()),
            Pair(C.RED, bMiss.toIntArray()),
            Pair(C.ORANGE, bQaza.toIntArray()),
            Pair(C.PURPLE, bNaf.toIntArray())
        )
        chartCard.addView(chart, lp(MATCH, dp(190)))

        // summary
        val sum = card(content)
        sum.addView(tv("💡 رپورٹ کا خلاصہ", 14f, C.DARK, true, Gravity.START))
        fun line(ok: Boolean, text: String) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val mark = tv(if (ok) "✔" else "!", 12f, Color.WHITE, true)
            mark.background = oval(if (ok) C.GREEN else C.ORANGE)
            r.addView(mark, lp(dp(22), dp(22)))
            r.addView(tv(text, 12f, C.TEXT, false, Gravity.START or Gravity.CENTER_VERTICAL).also { it.setPadding(dp(8), 0, 0, 0) }, lp(0, WRAP, 1f))
            sum.addView(r, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))
        }
        if (fardTotal == 0) line(false, "اس مدت میں رمضان کے فرض روزے شامل نہیں ہیں۔")
        else if (kept == fardTotal) line(true, "تمام $fardTotal فرض روزے رکھے گئے۔")
        else line(false, "$fardTotal فرض روزوں میں سے $kept رکھے گئے اور $missed چھوڑے گئے۔")
        if (sehriDays + iftarDays > 0) line(true, "سحری کا ریکارڈ $sehriDays دن اور افطار کا ریکارڈ $iftarDays دن کا موجود ہے۔")
        else line(false, "سحری اور افطاری کا ریکارڈ موجود نہیں۔")
        if (prayers == 0) line(false, "اس مدت میں کوئی نماز درج نہیں۔")
        else if (prayers >= dates.size * 5) line(true, "تمام نمازیں ادا کی گئیں۔")
        else line(true, "$prayers نمازیں ادا کی گئیں (${dates.size * 5} میں سے)۔")
        if (paras > 0) line(true, "قرآن پاک کے $paras پارے پڑھے گئے۔") else line(false, "قرآن پاک کی تلاوت کا ریکارڈ نہیں ملا۔")
        if (nafli > 0) line(true, "$nafli نفلی روزے رکھے گئے۔") else line(false, "کوئی نفلی روزہ درج نہیں۔")
        if (qazaDone > 0) line(true, "$qazaDone قضا روزے ادا کیے گئے۔")
        if (notesCount > 0) line(true, "$notesCount ذاتی نوٹس لکھے گئے۔")
    }
}
