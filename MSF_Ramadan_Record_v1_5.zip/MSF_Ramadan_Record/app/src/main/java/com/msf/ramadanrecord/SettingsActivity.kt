package com.msf.ramadanrecord

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.TextView
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import android.graphics.Color

class SettingsActivity : BaseActivity() {

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.5"
    } catch (e: Exception) {
        "1.5"
    }

    private fun render() {
        val content = heroScreen("سیٹنگز", "اپنی سہولت کے مطابق ایپ کی ترتیبات کریں", 10)

        val name = Store.getStr(this, "profile_name")
        settingRow(content, R.drawable.ic_person, "میرا پروفائل",
            if (name.isEmpty()) "اپنا نام، تصویر اور دیگر معلومات دیکھیں اور تبدیل کریں" else name) {
            go(ProfileActivity::class.java)
        }

        settingRow(content, R.drawable.ic_bell, "اطلاعات کی ترتیبات (نوٹیفکیشنز)",
            "سحری، افطار، نماز اور قرآن کی یاد دہانیوں کو کنٹرول کریں") {
            go(NotificationsActivity::class.java)
        }

        settingRow(content, R.drawable.ic_calendar, "رمضان کی ترتیبات",
            "روزوں کی تعداد، یکم رمضان، ہجری تاریخ اور اوقات",
            chip = "${Store.totalDays(this)} دن") {
            go(RamadanSettingsActivity::class.java)
        }

        settingRow(content, R.drawable.ic_language, "زبان / Language", "ایپ کی زبان اور فونٹ منتخب کریں",
            chip = "اردو") { chooseLanguage() }

        settingRow(content, R.drawable.ic_palette, "تھیم / رنگ کا موڈ", "ایپ کے ڈیزائن کا رنگ منتخب کریں",
            chip = if (Store.darkMode(this)) "ڈارک موڈ" else "لائٹ موڈ") { chooseTheme() }

        settingRow(content, R.drawable.ic_volume, "آواز و کمپن", "اطلاعات کے لیے آواز اور کمپن آن آف کریں",
            switchOn = Store.soundOn(this)) {
            val on = !Store.soundOn(this)
            Store.setSoundOn(this, on)
            toast(if (on) "آواز و کمپن آن" else "آواز و کمپن آف")
            render()
        }

        settingRow(content, R.drawable.ic_lock, "خودکار لاک", "کچھ دیر کے بعد ایپ کو خودکار لاک کریں",
            switchOn = Store.lockOn(this)) { toggleLock() }

        settingRow(content, R.drawable.ic_backup, "ڈیٹا کا بیک اپ", "اپنا ڈیٹا محفوظ رکھیں") {
            go(DataActivity::class.java)
        }

        settingRow(content, R.drawable.ic_mail, "رابطہ کریں", "کسی بھی مسئلے یا مشورے کے لیے ہم سے رابطہ کریں") {
            contactUs()
        }

        settingRow(content, R.drawable.ic_info, "ایپ کے بارے میں", "ورژن اور دیگر معلومات دیکھیں",
            chip = "ورژن ${versionName()}") { aboutApp() }

        settingRow(content, R.drawable.ic_shield, "رازداری کی پالیسی", "ہماری رازداری کی پالیسی پڑھیں") {
            val i = Intent(this, PolicyActivity::class.java)
            i.putExtra("kind", 0)
            startActivity(i)
        }

        settingRow(content, R.drawable.ic_doc, "شرائط و ضوابط", "ایپ کے استعمال کی شرائط پڑھیں") {
            val i = Intent(this, PolicyActivity::class.java)
            i.putExtra("kind", 1)
            startActivity(i)
        }

        val out = LinearLayout(this)
        out.orientation = LinearLayout.HORIZONTAL
        out.gravity = Gravity.CENTER
        out.background = bg(C.DARK, 26, C.GOLD, 2)
        out.setPadding(dp(16), dp(10), dp(16), dp(10))
        val oi = ImageView(this)
        oi.setImageResource(R.drawable.ic_logout)
        out.addView(oi, lp(dp(24), dp(24)))
        out.addView(tv("لاگ آؤٹ", 17f, Color.WHITE, true), lp(WRAP, WRAP).margins(dp(10), 0, dp(10), 0))
        out.setOnClickListener { logout() }
        val outLp = lp(dp(240), WRAP).margins(0, dp(14), 0, dp(8))
        outLp.gravity = Gravity.CENTER_HORIZONTAL
        content.addView(out, outLp)
    }

    private fun chooseLanguage() {
        AlertDialog.Builder(this)
            .setTitle("زبان / Language")
            .setItems(arrayOf("اردو (موجودہ زبان)", "English (جلد آ رہی ہے)", "فونٹ منتخب کریں  —  ${Fonts.labelOf(Fonts.file)}")) { _, which ->
                when (which) {
                    1 -> toast("انگریزی زبان جلد شامل کی جائے گی")
                    2 -> chooseFont()
                }
            }
            .setNegativeButton("بند کریں", null)
            .show()
    }

    private fun chooseFont() {
        val cur = Fonts.file
        val ctx = this
        val adapter = object : ArrayAdapter<Fonts.F>(this, 0, Fonts.ALL) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val f = getItem(position)!!
                val t = TextView(ctx)
                t.text = (if (f.file == cur) "✔  " else "") + f.label + "\nاللہ کے نام سے • رمضان المبارک 1448"
                Fonts.load(ctx, f.file)?.let { t.typeface = it }
                t.textSize = 18f
                t.setLineSpacing(0f, 1.2f)
                t.setPadding(dp(20), dp(12), dp(20), dp(12))
                t.gravity = Gravity.START
                t.textDirection = View.TEXT_DIRECTION_RTL
                return t
            }
        }
        AlertDialog.Builder(this)
            .setTitle("فونٹ منتخب کریں")
            .setAdapter(adapter) { _, which ->
                Fonts.set(ctx, Fonts.ALL[which].file)
                recreate()
            }
            .setNegativeButton("بند کریں", null)
            .show()
    }

    private fun chooseTheme() {
        val cur = if (Store.darkMode(this)) 1 else 0
        AlertDialog.Builder(this)
            .setTitle("تھیم / رنگ کا موڈ")
            .setSingleChoiceItems(arrayOf("لائٹ موڈ", "ڈارک موڈ"), cur) { d, which ->
                d.dismiss()
                if (which != cur) {
                    Store.setDarkMode(this, which == 1)
                    recreate()
                }
            }
            .setNegativeButton("بند کریں", null)
            .show()
    }

    private fun pinDialog(title: String, onOk: (String) -> Unit) {
        val et = EditText(this)
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        et.filters = arrayOf(InputFilter.LengthFilter(4))
        et.gravity = Gravity.CENTER
        et.textSize = 24f
        et.hint = "- - - -"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(et)
            .setPositiveButton("ٹھیک ہے") { _, _ ->
                val v = et.text.toString()
                if (v.length == 4) onOk(v) else toast("پن 4 ہندسوں کا ہونا چاہیے")
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun toggleLock() {
        if (Store.lockOn(this)) {
            pinDialog("بند کرنے کے لیے موجودہ پن لکھیں") { v ->
                if (Store.checkPin(this, v)) {
                    Store.setLockOn(this, false)
                    Store.setPin(this, "")
                    toast("خودکار لاک بند ہو گیا")
                    render()
                } else toast("غلط پن")
            }
        } else {
            pinDialog("نیا پن (4 ہندسے)") { p1 ->
                pinDialog("پن دوبارہ لکھیں") { p2 ->
                    if (p1 == p2) {
                        Store.setPin(this, p1)
                        Store.setLockOn(this, true)
                        AppLock.unlockNow()
                        toast("خودکار لاک آن ہو گیا (30 سیکنڈ بعد لاک ہوگا)")
                        render()
                    } else toast("دونوں پن مختلف ہیں")
                }
            }
        }
    }

    private fun contactUs() {
        AlertDialog.Builder(this)
            .setTitle("رابطہ کریں")
            .setItems(arrayOf("ای میل بھیجیں", "ایپ شیئر کریں")) { _, which ->
                try {
                    if (which == 0) {
                        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
                        i.putExtra(Intent.EXTRA_EMAIL, arrayOf(AppInfo.SUPPORT_EMAIL))
                        i.putExtra(Intent.EXTRA_SUBJECT, "MSF RamdanulMubarak Record - رابطہ")
                        startActivity(i)
                    } else {
                        val i = Intent(Intent.ACTION_SEND)
                        i.type = "text/plain"
                        i.putExtra(Intent.EXTRA_TEXT, AppInfo.SHARE_TEXT)
                        startActivity(Intent.createChooser(i, "شیئر کریں"))
                    }
                } catch (e: ActivityNotFoundException) {
                    toast("کوئی ایپ نہیں ملی")
                }
            }
            .setNegativeButton("بند کریں", null)
            .show()
    }

    private fun aboutApp() {
        AlertDialog.Builder(this)
            .setTitle("MSF RamdanulMubarak Record")
            .setMessage("ورژن ${versionName()}\n\nرمضان المبارک کے روزوں، نمازوں، قرآن پاک اور نوٹس کا ریکارڈ رکھنے والی ایپ۔\n\nآپ کا تمام ڈیٹا آپ کے اپنے موبائل میں محفوظ رہتا ہے۔")
            .setPositiveButton("ٹھیک ہے", null)
            .show()
    }

    private fun logout() {
        val locked = Store.lockOn(this)
        AlertDialog.Builder(this)
            .setTitle("لاگ آؤٹ")
            .setMessage(if (locked) "ایپ لاک ہو کر بند ہو جائے گی۔ دوبارہ کھولنے کے لیے پن لکھنا ہوگا۔" else "ایپ بند ہو جائے گی۔ آپ کا ریکارڈ محفوظ رہے گا۔")
            .setPositiveButton("ٹھیک ہے") { _, _ ->
                AppLock.unlocked = false
                finishAffinity()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }
}
