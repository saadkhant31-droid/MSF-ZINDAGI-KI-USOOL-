package com.msf.ramadanrecord

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate

class QazaActivity : BaseActivity() {

    private val reasons = arrayOf("بیماری", "سفر", "خاندان کی وجہ سے", "دوسری وجہ")
    private val colW = intArrayOf(112, 64, 64, 56, 130, 84, 150, 90)  // dp, right-to-left

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val content = heroScreen("قضا روزوں کا ریکارڈ", "اللہ کے لیے قضا روزے رکھیں اور اپنی عبادت مکمل کریں", 4)
        val list = Store.qazas(this)
        val total = list.size
        val done = list.count { it.done }
        val rem = total - done
        val last = list.maxByOrNull { it.date }
        val lastText = if (last != null) Dates.greg(LocalDate.parse(last.date)) else "—"

        // ---- summary ----
        content.addView(sectionBar("📄 قضا روزوں کا خلاصہ", null), lp(MATCH, WRAP).margins(dp(4), dp(4), dp(4), 0))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val tiles = listOf(
            summaryTile("📋", "کل قضا روزے", total.toString(), C.col("#0C4A2C")),
            summaryTile("✔", "ادا کیے گئے قضا روزے", done.toString(), C.BLUE),
            summaryTile("⏳", "باقی قضا روزے", rem.toString(), C.col("#E0A21B")),
            summaryTile("📅", "آخری قضا روزہ", lastText, C.col("#9A7AD1"))
        )
        for (t in tiles) row.addView(t, lp(0, WRAP, 1f).margins(dp(3), 0, dp(3), 0))
        content.addView(row, lp(MATCH, WRAP).margins(0, dp(6), 0, 0))

        // ---- record table ----
        val addBtn = tv("＋ نیا قضا روزہ شامل کریں", 12f, Color.WHITE, true)
        addBtn.background = bg(C.GREEN, 18, C.GOLD, 1)
        addBtn.setPadding(dp(12), dp(7), dp(12), dp(7))
        addBtn.setOnClickListener { editDialog(-1) }
        content.addView(sectionBar("📅 قضا روزوں کا ریکارڈ", addBtn), lp(MATCH, WRAP).margins(dp(4), dp(12), dp(4), 0))

        val shown = list.withIndex().sortedBy { it.value.date }
        content.addView(table(shown), lp(MATCH, WRAP).margins(dp(4), dp(6), dp(4), 0))

        val note = card(content, C.col("#E8F2DC"))
        note.addView(tv("نوٹ: قضا روزوں کی تعداد تبدیل ہو سکتی ہے۔ یہ ریکارڈ آپ کے ذاتی اندراج پر مبنی ہے۔ ہر قضا روزے کے ساتھ اس کی وجہ اور تاریخ درج کریں تاکہ حساب مکمل رہے۔ \"روزہ رکھا؟\" کے بٹن پر ٹیپ کر کے ہاں/نہیں بدلا جا سکتا ہے۔", 12f, C.TEXT, false, Gravity.START))
    }

    private fun table(shown: List<IndexedValue<QazaRec>>): View {
        val heads = arrayOf("تاریخ", "دن", "مہینہ", "سال", "قضا کی وجہ", "روزہ رکھا؟", "نوٹ", "عملیات")
        val (hs, tbl) = tableShell(heads, colW)

        if (shown.isEmpty()) {
            tbl.addView(tv("ابھی کوئی ریکارڈ نہیں۔ \"نیا قضا روزہ شامل کریں\" دبائیں۔", 13f, C.MUTED).also { it.setPadding(dp(16), dp(20), dp(16), dp(20)) })
        }
        var n = 0
        for (iv in shown) {
            val r = iv.value
            val date = LocalDate.parse(r.date)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setBackgroundColor(if (n % 2 == 0) C.col("#F4F7EE") else C.SURFACE)
            row.setPadding(0, dp(8), 0, dp(8))
            n++

            row.addView(cellBox(colW[0], tv(Dates.greg(date), 12f, C.TEXT)))
            row.addView(cellBox(colW[1], tv(Dates.urduDay(date), 12f, C.TEXT)))
            row.addView(cellBox(colW[2], tv(Dates.gMonths[date.monthValue - 1], 12f, C.TEXT)))
            row.addView(cellBox(colW[3], tv(date.year.toString(), 12f, C.TEXT)))
            row.addView(cellBox(colW[4], tv(reasons[r.reason.coerceIn(0, 3)], 12f, C.TEXT)))

            val st = pill(if (r.done) "ہاں" else "نہیں", if (r.done) C.GREEN else C.RED)
            st.setOnClickListener {
                val l = Store.qazas(this)
                if (iv.index in l.indices) {
                    l[iv.index] = l[iv.index].copy(done = !l[iv.index].done)
                    Store.saveQazas(this, l)
                }
                render()
            }
            row.addView(cellBox(colW[5], st))

            val nt = tv(if (r.note.isEmpty()) "-" else r.note, 11f, C.TEXT, false, Gravity.START or Gravity.CENTER_VERTICAL)
            nt.maxLines = 3
            nt.layoutParams = LinearLayout.LayoutParams(dp(colW[6]), WRAP)
            nt.setPadding(dp(6), 0, dp(6), 0)
            row.addView(nt)

            val act = LinearLayout(this)
            act.orientation = LinearLayout.HORIZONTAL
            val ed = tv("✏️", 17f, Color.BLACK)
            ed.setPadding(dp(8), dp(4), dp(8), dp(4))
            ed.setOnClickListener { editDialog(iv.index) }
            val del = tv("🗑", 17f, Color.BLACK)
            del.setPadding(dp(8), dp(4), dp(8), dp(4))
            del.setOnClickListener { confirmDelete(iv.index) }
            act.addView(ed)
            act.addView(del)
            row.addView(cellBox(colW[7], act))

            tbl.addView(row)
        }
        return hs
    }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this)
            .setMessage("یہ قضا روزے کا ریکارڈ حذف کریں؟")
            .setPositiveButton("حذف کریں") { _, _ ->
                val l = Store.qazas(this)
                if (index in l.indices) {
                    l.removeAt(index)
                    Store.saveQazas(this, l)
                }
                render()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun editDialog(index: Int) {
        val list = Store.qazas(this)
        val old: QazaRec? = if (index in list.indices) list[index] else null
        var date: LocalDate = if (old != null) LocalDate.parse(old.date) else LocalDate.now()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        box.addView(fieldLabel("تاریخ"))
        val dateBtn = tv(Dates.greg(date), 14f, Color.WHITE, true)
        dateBtn.background = bg(C.BLUE, 10)
        dateBtn.setPadding(dp(12), dp(10), dp(12), dp(10))
        dateBtn.setOnClickListener {
            DatePickerDialog(this, { _, y, m, d ->
                date = LocalDate.of(y, m + 1, d)
                dateBtn.text = Dates.greg(date)
            }, date.year, date.monthValue - 1, date.dayOfMonth).show()
        }
        box.addView(dateBtn, lp(MATCH, WRAP))

        box.addView(fieldLabel("قضا کی وجہ"))
        val reasonSp = spinnerOf(reasons, old?.reason ?: 0)
        box.addView(reasonSp, lp(MATCH, WRAP))

        box.addView(fieldLabel("روزہ رکھا؟"))
        val doneSp = spinnerOf(arrayOf("ہاں", "نہیں"), if (old?.done == true) 0 else 1)
        box.addView(doneSp, lp(MATCH, WRAP))

        box.addView(fieldLabel("نوٹ"))
        val noteEt = EditText(this)
        noteEt.setText(old?.note ?: "")
        noteEt.minLines = 2
        noteEt.textSize = 13f
        noteEt.gravity = Gravity.TOP or Gravity.START
        box.addView(noteEt, lp(MATCH, WRAP))

        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)

        AlertDialog.Builder(this)
            .setTitle(if (old != null) "قضا روزے میں ترمیم" else "نیا قضا روزہ")
            .setView(scroll)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                val rec = QazaRec(
                    date.toString(),
                    reasonSp.selectedItemPosition,
                    doneSp.selectedItemPosition == 0,
                    noteEt.text.toString().trim(),
                    old?.src ?: 0
                )
                if (old != null) list[index] = rec else list.add(rec)
                Store.saveQazas(this, list)
                render()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }
}
