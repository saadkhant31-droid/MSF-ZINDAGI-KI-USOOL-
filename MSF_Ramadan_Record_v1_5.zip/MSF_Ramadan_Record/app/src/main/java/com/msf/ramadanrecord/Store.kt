package com.msf.ramadanrecord

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.temporal.ChronoField
import java.time.temporal.ChronoUnit

/** cat: 0 fast, 1 qaza, 2 prayer, 3 sehri, 4 iftar, 5 quran, 6 other | min: minutes since midnight, -1 = no time */
data class Note(val text: String, val date: String, val cat: Int = 6, val min: Int = -1)

/** reason: 0 illness, 1 travel, 2 family, 3 other | src: Ramadan day number this qaza came from (0 = added by hand) */
data class QazaRec(val date: String, val reason: Int, val done: Boolean, val note: String, val src: Int = 0)

/** reason: 0 none, 1 travel, 2 illness, 3 other */
data class FardRec(val kept: Boolean, val recorded: Boolean, val reason: Int, val note: String)

/** type: 0 Mon,1 Thu,2 Ayyam-e-Bees,3 Shawwal 6,4 other | status: 0 kept,1 broken,2 not kept | reason: 0 none,1 deliberate,2 illness,3 other */
data class NafliRec(val date: String, val type: Int, val status: Int, val reason: Int, val note: String)

object Store {
    private fun p(c: Context): SharedPreferences =
        c.getSharedPreferences("msf_ramadan", Context.MODE_PRIVATE)

    private fun getSet(c: Context, key: String): MutableSet<String> {
        val s = p(c).getStringSet(key, null)
        return if (s == null) HashSet<String>() else HashSet<String>(s)
    }

    private fun toggleIn(c: Context, key: String, item: String): Boolean {
        val s = getSet(c, key)
        val on: Boolean
        if (s.contains(item)) {
            s.remove(item)
            on = false
        } else {
            s.add(item)
            on = true
        }
        p(c).edit().putStringSet(key, s).apply()
        return on
    }

    // ---- settings ----
    fun totalDays(c: Context): Int = p(c).getInt("total_days", 30)
    fun setTotalDays(c: Context, v: Int) { p(c).edit().putInt("total_days", v).apply() }

    fun offset(c: Context): Int = p(c).getInt("offset", 0)
    fun setOffset(c: Context, v: Int) { p(c).edit().putInt("offset", v).apply() }

    fun hasCustomStart(c: Context): Boolean = p(c).contains("start_epoch")

    fun setStart(c: Context, d: LocalDate?) {
        val e = p(c).edit()
        if (d == null) e.remove("start_epoch") else e.putLong("start_epoch", d.toEpochDay())
        e.apply()
    }

    fun defaultStart(c: Context): LocalDate {
        val off = offset(c)
        return try {
            val today = LocalDate.now().plusDays(off.toLong())
            val h = HijrahDate.from(today)
            var y = h.get(ChronoField.YEAR)
            if (h.get(ChronoField.MONTH_OF_YEAR) >= 10) y += 1
            LocalDate.from(HijrahDate.of(y, 9, 1)).minusDays(off.toLong())
        } catch (e: Exception) {
            LocalDate.now()
        }
    }

    fun startDate(c: Context): LocalDate {
        val sp = p(c)
        return if (sp.contains("start_epoch")) LocalDate.ofEpochDay(sp.getLong("start_epoch", 0L))
        else defaultStart(c)
    }

    fun ramadanDay(c: Context): Int =
        ChronoUnit.DAYS.between(startDate(c), LocalDate.now()).toInt() + 1

    // ---- fasts ----
    fun fastKept(c: Context, d: Int): Boolean = getSet(c, "fasts").contains(d.toString())
    fun keptCount(c: Context): Int = getSet(c, "fasts").size

    private fun fardObj(c: Context): JSONObject =
        try { JSONObject(p(c).getString("fard_info", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun saveFardObj(c: Context, o: JSONObject) {
        p(c).edit().putString("fard_info", o.toString()).apply()
    }

    fun toggleFast(c: Context, d: Int): Boolean {
        val on = toggleIn(c, "fasts", d.toString())
        val obj = fardObj(c)
        val o = obj.optJSONObject(d.toString())
        if (on) {
            if (o != null) { o.put("r", 0); obj.put(d.toString(), o) }
        } else {
            obj.remove(d.toString())
        }
        saveFardObj(c, obj)
        return on
    }

    fun fardRec(c: Context, d: Int): FardRec {
        val kept = fastKept(c, d)
        val o = fardObj(c).optJSONObject(d.toString())
        if (kept) return FardRec(true, true, 0, o?.optString("n", "") ?: "")
        if (o == null) return FardRec(false, false, 0, "")
        return FardRec(false, true, o.optInt("r", 0), o.optString("n", ""))
    }

    /** status: 0 kept, 1 not kept, 2 clear record */
    fun setFard(c: Context, d: Int, status: Int, reason: Int, note: String) {
        val set = getSet(c, "fasts")
        if (status == 0) set.add(d.toString()) else set.remove(d.toString())
        p(c).edit().putStringSet("fasts", set).apply()
        val obj = fardObj(c)
        if (status == 2) {
            obj.remove(d.toString())
        } else {
            val o = JSONObject()
            o.put("s", status)
            o.put("r", if (status == 1) reason else 0)
            o.put("n", note)
            obj.put(d.toString(), o)
        }
        saveFardObj(c, obj)
    }

    // ---- qaza ----
    fun qazas(c: Context): MutableList<QazaRec> {
        val sp = p(c)
        if (!sp.contains("qaza_recs")) {
            // migrate old counters (total / done) into records
            val total = sp.getInt("qaza_total", 0)
            val done = sp.getInt("qaza_done", 0)
            val list = ArrayList<QazaRec>()
            for (i in 0 until total) list.add(QazaRec(LocalDate.now().toString(), 3, i < done, "پرانا اندراج", 0))
            saveQazas(c, list)
            sp.edit().remove("qaza_total").remove("qaza_done").apply()
            return list
        }
        val out = ArrayList<QazaRec>()
        try {
            val arr = JSONArray(sp.getString("qaza_recs", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(QazaRec(o.getString("d"), o.getInt("r"), o.getBoolean("x"), o.getString("n"), o.optInt("f", 0)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveQazas(c: Context, list: List<QazaRec>) {
        val arr = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("d", r.date)
            o.put("r", r.reason)
            o.put("x", r.done)
            o.put("n", r.note)
            o.put("f", r.src)
            arr.put(o)
        }
        p(c).edit().putString("qaza_recs", arr.toString()).apply()
    }

    fun qazaTotal(c: Context): Int = qazas(c).size
    fun qazaDone(c: Context): Int = qazas(c).count { it.done }

    // ---- prayers ----
    fun prayerOn(c: Context, date: String, idx: Int): Boolean = getSet(c, "prayers").contains("$date:$idx")
    fun togglePrayer(c: Context, date: String, idx: Int): Boolean {
        val on = !prayerOn(c, date, idx)
        setPrayerStatus(c, date, idx, if (on) 1 else 0)
        if (on && date == LocalDate.now().toString()) {
            val now = java.time.LocalTime.now()
            setPrayedTime(c, date, idx, now.hour * 60 + now.minute)
        }
        return on
    }

    /** 0 none, 1 prayed on time, 2 qaza (prayed late), 3 missed */
    fun prayerStatus(c: Context, date: String, idx: Int): Int {
        val v = getStr(c, "pst:$date:$idx").toIntOrNull()
        if (v != null) return v
        return if (prayerOn(c, date, idx)) 1 else 0
    }

    fun setPrayerStatus(c: Context, date: String, idx: Int, st: Int) {
        val set = getSet(c, "prayers")
        val k = "$date:$idx"
        if (st == 1 || st == 2) set.add(k) else set.remove(k)
        p(c).edit()
            .putStringSet("prayers", set)
            .putString("pst:$date:$idx", if (st == 0) "" else st.toString())
            .apply()
        if (st == 0 || st == 3) setPrayedTime(c, date, idx, -1)
    }

    /** minutes since midnight when the prayer was actually offered, -1 = not set */
    fun prayedTime(c: Context, date: String, idx: Int): Int = getStr(c, "ptm:$date:$idx").toIntOrNull() ?: -1
    fun setPrayedTime(c: Context, date: String, idx: Int, min: Int) {
        putStr(c, "ptm:$date:$idx", if (min < 0) "" else min.toString())
    }

    fun prayerNote(c: Context, date: String, idx: Int): String = getStr(c, "pnt:$date:$idx")
    fun setPrayerNote(c: Context, date: String, idx: Int, note: String) { putStr(c, "pnt:$date:$idx", note) }

    /** start time of each prayer (editable) */
    private val defaultPrayerMins = intArrayOf(298, 760, 985, 1087, 1160)
    fun prayerTime(c: Context, idx: Int): Int = p(c).getInt("ptime$idx", defaultPrayerMins[idx])
    fun setPrayerTime(c: Context, idx: Int, min: Int) { p(c).edit().putInt("ptime$idx", min).apply() }
    fun prayersCount(c: Context): Int = getSet(c, "prayers").size

    // ---- quran ----
    fun paraRead(c: Context, n: Int): Boolean = getSet(c, "paras").contains(n.toString())
    fun togglePara(c: Context, n: Int): Boolean {
        val on = toggleIn(c, "paras", n.toString())
        val log = getSet(c, "para_log")
        val round = khatam(c)
        if (on) {
            log.add("${LocalDate.now()}:$n:$round")
        } else {
            log.removeAll { it.endsWith(":$n:$round") }
        }
        p(c).edit().putStringSet("para_log", log).apply()
        return on
    }

    /** number of paras marked as read on dates between from and to (inclusive) */
    fun parasBetween(c: Context, from: LocalDate, to: LocalDate): Int {
        var n = 0
        for (e in getSet(c, "para_log")) {
            val d = try { LocalDate.parse(e.substring(0, 10)) } catch (ex: Exception) { continue }
            if (!d.isBefore(from) && !d.isAfter(to)) n++
        }
        return n
    }

    fun prayersOn(c: Context, date: LocalDate): Int {
        var n = 0
        for (i in 0 until 5) if (prayerOn(c, date.toString(), i)) n++
        return n
    }

    fun sehriRecorded(c: Context, date: LocalDate): Boolean =
        listOf("woke", "ate", "before", "food", "note").any { getStr(c, "sh:$date:$it").isNotEmpty() }

    fun iftarRecorded(c: Context, date: LocalDate): Boolean =
        listOf("opened", "food", "with", "note").any { getStr(c, "if:$date:$it").isNotEmpty() }
    fun parasCount(c: Context): Int = getSet(c, "paras").size
    fun khatam(c: Context): Int = p(c).getInt("khatam", 0)
    fun newKhatamRound(c: Context) {
        val e = p(c).edit()
        if (parasCount(c) >= 30) e.putInt("khatam", khatam(c) + 1)
        e.putStringSet("paras", HashSet<String>())
        e.apply()
    }

    // ---- nafli ----
    fun naflis(c: Context): MutableList<NafliRec> {
        val out = ArrayList<NafliRec>()
        try {
            val arr = JSONArray(p(c).getString("nafli_recs", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(NafliRec(o.getString("d"), o.getInt("t"), o.getInt("s"), o.getInt("r"), o.getString("n")))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveNaflis(c: Context, list: List<NafliRec>) {
        val arr = JSONArray()
        for (r in list) {
            val o = JSONObject()
            o.put("d", r.date)
            o.put("t", r.type)
            o.put("s", r.status)
            o.put("r", r.reason)
            o.put("n", r.note)
            arr.put(o)
        }
        p(c).edit().putString("nafli_recs", arr.toString()).apply()
    }

    // ---- generic strings (sehri / iftar records) ----
    fun getStr(c: Context, key: String): String = p(c).getString(key, "") ?: ""
    fun putStr(c: Context, key: String, v: String) { p(c).edit().putString(key, v).apply() }

    // ---- times ----
    fun sehri(c: Context): Int = p(c).getInt("sehri", 238)
    fun iftar(c: Context): Int = p(c).getInt("iftar", 1108)
    fun setSehri(c: Context, v: Int) { p(c).edit().putInt("sehri", v).apply() }
    fun setIftar(c: Context, v: Int) { p(c).edit().putInt("iftar", v).apply() }

    // ---- notes ----
    fun notes(c: Context): MutableList<Note> {
        val out = ArrayList<Note>()
        try {
            val arr = JSONArray(p(c).getString("notes", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Note(o.getString("t"), o.getString("d"), o.optInt("c", 6), o.optInt("m", -1)))
            }
        } catch (e: Exception) {
        }
        return out
    }

    fun saveNotes(c: Context, list: List<Note>) {
        val arr = JSONArray()
        for (n in list) {
            val o = JSONObject()
            o.put("t", n.text)
            o.put("d", n.date)
            o.put("c", n.cat)
            o.put("m", n.min)
            arr.put(o)
        }
        p(c).edit().putString("notes", arr.toString()).apply()
    }

    // ---- app settings (v1.4) ----
    fun darkMode(c: Context): Boolean = p(c).getBoolean("dark_mode", false)
    fun setDarkMode(c: Context, v: Boolean) {
        p(c).edit().putBoolean("dark_mode", v).apply()
        C.dark = v
    }

    fun soundOn(c: Context): Boolean = p(c).getBoolean("sound_on", true)
    fun setSoundOn(c: Context, v: Boolean) { p(c).edit().putBoolean("sound_on", v).apply() }

    fun lockOn(c: Context): Boolean = p(c).getBoolean("lock_on", false)
    fun setLockOn(c: Context, v: Boolean) { p(c).edit().putBoolean("lock_on", v).apply() }
    fun pinHash(c: Context): String = p(c).getString("pin_hash", "") ?: ""
    fun setPin(c: Context, pin: String) {
        p(c).edit().putString("pin_hash", if (pin.isEmpty()) "" else hashPin(pin)).apply()
    }
    fun checkPin(c: Context, pin: String): Boolean = pinHash(c).isNotEmpty() && pinHash(c) == hashPin(pin)
    private fun hashPin(pin: String): String {
        val md = java.security.MessageDigest.getInstance("SHA-256")
        return md.digest(("msf-ramadan:$pin").toByteArray()).joinToString("") { "%02x".format(it) }
    }

    // reminders: idx 0 sehri, 1 iftar, 2 namaz, 3 quran
    private val defaultRemMins = intArrayOf(210, 1090, 760, 1260)
    fun remOn(c: Context, i: Int): Boolean = p(c).getBoolean("rem_on$i", false)
    fun setRemOn(c: Context, i: Int, v: Boolean) { p(c).edit().putBoolean("rem_on$i", v).apply() }
    fun remMin(c: Context, i: Int): Int = p(c).getInt("rem_min$i", defaultRemMins[i])
    fun setRemMin(c: Context, i: Int, v: Int) { p(c).edit().putInt("rem_min$i", v).apply() }

    // ---- backup / restore ----
    private val PRIVATE_KEYS = setOf("pin_hash")

    fun exportJson(c: Context): String {
        val root = JSONObject()
        root.put("app", "msf_ramadan_record")
        root.put("version", 1)
        val data = JSONObject()
        for ((k, v) in p(c).all) {
            if (k in PRIVATE_KEYS) continue
            val o = JSONObject()
            when (v) {
                is Boolean -> { o.put("t", "b"); o.put("v", v) }
                is Int -> { o.put("t", "i"); o.put("v", v) }
                is Long -> { o.put("t", "l"); o.put("v", v) }
                is Float -> { o.put("t", "f"); o.put("v", v.toDouble()) }
                is String -> { o.put("t", "s"); o.put("v", v) }
                is Set<*> -> {
                    val arr = JSONArray()
                    for (x in v) arr.put(x.toString())
                    o.put("t", "set"); o.put("v", arr)
                }
                else -> continue
            }
            data.put(k, o)
        }
        root.put("data", data)
        return root.toString()
    }

    /** returns false when the text is not a valid backup of this app */
    fun importJson(c: Context, text: String): Boolean {
        try {
            val root = JSONObject(text)
            if (root.optString("app") != "msf_ramadan_record") return false
            val data = root.getJSONObject("data")
            val e = p(c).edit()
            val keep = pinHash(c)
            e.clear()
            if (keep.isNotEmpty()) e.putString("pin_hash", keep)
            val keys = data.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                if (k in PRIVATE_KEYS) continue
                val o = data.getJSONObject(k)
                when (o.getString("t")) {
                    "b" -> e.putBoolean(k, o.getBoolean("v"))
                    "i" -> e.putInt(k, o.getInt("v"))
                    "l" -> e.putLong(k, o.getLong("v"))
                    "f" -> e.putFloat(k, o.getDouble("v").toFloat())
                    "s" -> e.putString(k, o.getString("v"))
                    "set" -> {
                        val arr = o.getJSONArray("v")
                        val set = HashSet<String>()
                        for (i in 0 until arr.length()) set.add(arr.getString(i))
                        e.putStringSet(k, set)
                    }
                }
            }
            e.commit()
            return true
        } catch (ex: Exception) {
            return false
        }
    }

    fun resetAll(c: Context) {
        p(c).edit().clear().apply()
    }
}
