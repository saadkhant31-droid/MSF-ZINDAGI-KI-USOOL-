package com.msf.ramadanrecord

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog

class RamadanSettingsActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val content = screen("رمضان کی ترتیبات", 10)

        heading(content, "رمضان")
        val c1 = card(content)
        c1.addView(tv("رمضان کے کل روزے: ${Store.totalDays(this)}", 15f, C.TEXT, true))
        c1.addView(button("29 یا 30 منتخب کریں", C.GREEN) {
            AlertDialog.Builder(this)
                .setTitle("رمضان کے کل روزے")
                .setItems(arrayOf("29", "30")) { _, which ->
                    Store.setTotalDays(this, if (which == 0) 29 else 30)
                    render()
                }
                .show()
        }, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))

        val start = Store.startDate(this)
        val c2 = card(content)
        c2.addView(tv("یکم رمضان: ${Dates.greg(start)}" + if (Store.hasCustomStart(this)) "" else "  (خودکار)", 15f, C.TEXT, true))
        c2.addView(button("چاند کے مطابق تاریخ منتخب کریں", C.BLUE) {
            DatePickerDialog(this, { _, y, m, d ->
                Store.setStart(this, java.time.LocalDate.of(y, m + 1, d))
                render()
            }, start.year, start.monthValue - 1, start.dayOfMonth).show()
        }, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))
        if (Store.hasCustomStart(this)) {
            c2.addView(button("خودکار تاریخ بحال کریں", C.MUTED) {
                Store.setStart(this, null)
                render()
            }, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))
        }

        stepper(content, "ہجری تاریخ میں فرق (دن)", C.PURPLE,
            { Store.offset(this) },
            { v ->
                if (v < -2 || v > 2) false
                else {
                    Store.setOffset(this, v)
                    true
                }
            }
        ) { }

        addButton(content, "سحری و افطار کے اوقات", C.ORANGE) { go(TimesActivity::class.java) }
    }
}
