package com.msf.ramadanrecord

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import java.time.LocalDate

class CalendarActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val content = screen("رمضان کیلنڈر", 2)
        val start = Store.startDate(this)
        val today = LocalDate.now()
        val off = Store.offset(this)

        val head = card(content, C.DARK)
        head.addView(tv("شروع: ${Dates.greg(start)}  •  ہجری: ${Dates.hijri(start, off)}", 13f, Color.WHITE, true))
        head.addView(tv("روزہ رکھنے/نہ رکھنے کے لیے دن پر ٹیپ کریں", 11f, C.col("#F3E3A5")))

        for (d in 1..Store.totalDays(this)) {
            val date = start.plusDays((d - 1).toLong())
            val row = card(content, if (date == today) C.HIGHLIGHT else C.CARD)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL

            val info = LinearLayout(this)
            info.orientation = LinearLayout.VERTICAL
            info.addView(tv("$d رمضان" + if (date == today) "  (آج)" else "", 15f, C.DARK, true, Gravity.START))
            info.addView(tv("${Dates.urduDay(date)} • ${Dates.greg(date)}", 12f, C.MUTED, false, Gravity.START))
            row.addView(info, lp(0, WRAP, 1f))

            val status = tv("", 14f, Color.WHITE, true)
            status.setPadding(dp(14), dp(8), dp(14), dp(8))
            fun paint(on: Boolean) {
                status.text = if (on) "✔ رکھا" else "باقی"
                status.background = bg(if (on) C.GREEN else C.col("#9AA39D"), 16)
            }
            paint(Store.fastKept(this, d))
            status.setOnClickListener { paint(Store.toggleFast(this, d)) }
            row.addView(status, lp(WRAP, WRAP))
        }
    }
}
