package com.msf.ramadanrecord

import android.os.Bundle
import android.view.Gravity

class PolicyActivity : BaseActivity() {

    private val privacy = listOf(
        "MSF RamdanulMubarak Record آپ کی رازداری کا احترام کرتی ہے۔" to "",
        "1. معلومات کا ذخیرہ" to "آپ کے روزے، نمازیں، قرآن، نوٹس اور پروفائل کی تمام معلومات صرف آپ کے اپنے موبائل میں محفوظ ہوتی ہیں۔",
        "2. انٹرنیٹ اور شیئرنگ" to "ایپ آپ کا ڈیٹا کسی سرور پر نہیں بھیجتی اور نہ ہی کسی تیسرے فریق کے ساتھ شیئر کرتی ہے۔",
        "3. اجازتیں" to "ایپ صرف یاد دہانی کے لیے نوٹیفکیشن کی اجازت مانگتی ہے۔ پروفائل تصویر آپ خود منتخب کرتے ہیں۔",
        "4. بیک اپ" to "بیک اپ فائل آپ کی مرضی سے بنتی ہے۔ اسے محفوظ جگہ رکھنا آپ کی ذمہ داری ہے۔",
        "5. پن لاک" to "پن صرف آپ کے موبائل میں خفیہ شکل میں محفوظ ہوتا ہے۔ پن بھول جانے پر ایپ کا ریکارڈ مٹا کر لاک ہٹایا جا سکتا ہے۔",
        "6. رابطہ" to "کسی سوال کے لیے سیٹنگز میں \"رابطہ کریں\" استعمال کریں۔"
    )

    private val terms = listOf(
        "MSF RamdanulMubarak Record استعمال کرنے کا مطلب ہے کہ آپ درج ذیل شرائط سے متفق ہیں۔" to "",
        "1. مقصد" to "یہ ایپ رمضان المبارک کے روزوں، نمازوں، قرآن پاک کی تلاوت اور ذاتی نوٹس کا ریکارڈ رکھنے کے لیے ہے۔",
        "2. اوقات" to "سحری، افطار اور نماز کے اوقات آپ خود درج کرتے ہیں۔ درست اوقات کے لیے اپنی مقامی مسجد یا مستند ذرائع سے تصدیق کریں۔",
        "3. تاریخ" to "ہجری تاریخ اندازے پر مبنی ہو سکتی ہے۔ چاند کے مطابق تاریخ آپ سیٹنگز میں خود تبدیل کر سکتے ہیں۔",
        "4. ڈیٹا کی ذمہ داری" to "ریکارڈ آپ کے موبائل میں رہتا ہے۔ موبائل تبدیل کرنے یا ایپ ہٹانے سے پہلے بیک اپ بنا لیں۔",
        "5. تبدیلیاں" to "ایپ کے نئے ورژن میں یہ شرائط تبدیل ہو سکتی ہیں۔"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isPrivacy = intent.getIntExtra("kind", 0) == 0
        val content = screen(if (isPrivacy) "رازداری کی پالیسی" else "شرائط و ضوابط", 10)
        val c = card(content)
        for ((head, body) in if (isPrivacy) privacy else terms) {
            if (body.isEmpty()) {
                c.addView(tv(head, 15f, C.TEXT, true, Gravity.START), lp(MATCH, WRAP).margins(0, 0, 0, dp(10)))
            } else {
                c.addView(tv(head, 15f, C.GREEN, true, Gravity.START), lp(MATCH, WRAP).margins(0, dp(8), 0, dp(2)))
                c.addView(tv(body, 14f, C.TEXT, false, Gravity.START).also { it.setLineSpacing(0f, 1.25f) }, lp(MATCH, WRAP))
            }
        }
    }
}
