package com.msf.ramadanrecord

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.graphics.drawable.GradientDrawable
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.max

open class BaseActivity : AppCompatActivity() {

    private var themeAtCreate = false
    private var fontAtCreate = ""

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        C.dark = Store.darkMode(this)
        themeAtCreate = C.dark
        fontAtCreate = Fonts.file
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(C.BG))
    }

    override fun onStart() {
        super.onStart()
        AppLock.check(this)
    }

    override fun onResume() {
        super.onResume()
        if (Store.darkMode(this) != themeAtCreate || Fonts.file != fontAtCreate) recreate()
    }

    override fun onStop() {
        super.onStop()
        AppLock.stopped()
    }

    fun go(target: Class<*>) {
        startActivity(Intent(this, target))
    }

    /** Builds a standard screen (top bar + scroll + optional bottom nav) and returns the content column. */
    protected fun screen(title: String, tab: Int = -1): LinearLayout {
        window.statusBarColor = C.DARK
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.layoutDirection = View.LAYOUT_DIRECTION_RTL
        outer.setBackgroundColor(C.BG)

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(C.DARK)
        bar.setPadding(dp(8), dp(10), dp(8), dp(10))
        val back = tv("→", 26f, Color.WHITE, true)
        back.setOnClickListener { finish() }
        bar.addView(back, lp(dp(48), WRAP))
        bar.addView(tv(title, 19f, Color.WHITE, true), lp(0, WRAP, 1f))
        bar.addView(View(this), lp(dp(48), 1))
        outer.addView(bar, lp(MATCH, WRAP))

        val scroll = ScrollView(this)
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(0, dp(6), 0, dp(20))
        scroll.addView(content, android.widget.FrameLayout.LayoutParams(MATCH, WRAP))
        outer.addView(scroll, lp(MATCH, 0, 1f))

        outer.addView(buildNav(tab), lp(MATCH, WRAP))
        setContentView(outer)
        return content
    }


    private fun heroBanner(title: String, subtitle: String): View {
        val f = FrameLayout(this)
        f.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#05241A"), Color.parseColor("#0E5A3A"), Color.parseColor("#A07F2B"))
        )
        val lanternL = tv("🏮", 44f, Color.WHITE)
        f.addView(lanternL, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.LEFT).also { it.setMargins(dp(10), 0, 0, dp(50)) })
        val lanternR = tv("🏮", 44f, Color.WHITE)
        f.addView(lanternR, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.RIGHT).also { it.setMargins(0, 0, dp(10), dp(50)) })

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        f.addView(logo, FrameLayout.LayoutParams(dp(120), dp(120), Gravity.TOP or Gravity.CENTER_HORIZONTAL).also { it.topMargin = dp(22) })

        val pill = tv(title, 18f, Color.WHITE, true)
        pill.background = bg(C.DARK, 20, C.GOLD, 2)
        pill.setPadding(dp(28), dp(6), dp(28), dp(6))
        f.addView(pill, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(74) })
        f.addView(tv(subtitle, 12f, Color.parseColor("#F3E3A5")), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).also { it.bottomMargin = dp(48) })

        val back = tv("‹", 30f, Color.WHITE, true)
        back.background = oval(C.DARK, C.GOLD, 2)
        back.setOnClickListener { finish() }
        f.addView(back, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.LEFT).also { it.setMargins(dp(12), dp(12), 0, 0) })

        val today = java.time.LocalDate.now()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.background = bg(C.DARK, 12, C.GOLD, 2)
        box.setPadding(dp(10), dp(6), dp(10), dp(6))
        box.addView(tv("📅 آج کی تاریخ", 10f, Color.WHITE))
        box.addView(tv(Dates.greg(today), 12f, Color.WHITE, true))
        box.addView(tv("(${Dates.urduDay(today)})", 10f, Color.WHITE))
        f.addView(box, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.RIGHT).also { it.setMargins(0, dp(12), dp(12), 0) })
        return f
    }

    /** Screen with the big banner header (used by Sehri/Iftar and Nafli screens). */
    protected fun heroScreen(title: String, subtitle: String, tab: Int, footer: View? = null): LinearLayout {
        window.statusBarColor = C.DARK
        val outer = LinearLayout(this)
        outer.orientation = LinearLayout.VERTICAL
        outer.layoutDirection = View.LAYOUT_DIRECTION_RTL
        outer.setBackgroundColor(C.BG)
        val scroll = ScrollView(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        outer.addView(scroll, lp(MATCH, 0, 1f))
        if (footer != null) outer.addView(footer, lp(MATCH, WRAP))
        outer.addView(buildNav(tab), lp(MATCH, WRAP))
        col.addView(heroBanner(title, subtitle), lp(MATCH, dp(280)))
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        val r = dp(26).toFloat()
        val g = GradientDrawable()
        g.setColor(C.BG)
        g.cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        content.background = g
        content.setPadding(dp(8), dp(12), dp(8), dp(20))
        col.addView(content, lp(MATCH, WRAP).margins(0, -dp(26), 0, 0))
        setContentView(outer)
        return content
    }

    protected fun card(parent: LinearLayout, color: Int = C.CARD): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = bg(color, 16, C.BORDER, 1)
        c.setPadding(dp(14), dp(12), dp(14), dp(12))
        parent.addView(c, lp(MATCH, WRAP).margins(dp(12), dp(6), dp(12), dp(6)))
        return c
    }

    protected fun button(text: String, color: Int, onClick: () -> Unit): TextView {
        val b = tv(text, 15f, Color.WHITE, true)
        b.background = bg(color, 14)
        b.setPadding(dp(16), dp(12), dp(16), dp(12))
        b.setOnClickListener { onClick() }
        return b
    }

    protected fun addButton(parent: LinearLayout, text: String, color: Int, onClick: () -> Unit) {
        parent.addView(button(text, color, onClick), lp(MATCH, WRAP).margins(dp(12), dp(6), dp(12), dp(6)))
    }

    protected fun heading(parent: LinearLayout, text: String) {
        val t = tv(text, 16f, C.DARK, true, Gravity.START or Gravity.CENTER_VERTICAL)
        parent.addView(t, lp(MATCH, WRAP).margins(dp(16), dp(10), dp(16), dp(2)))
    }

    protected fun paintCheck(t: TextView, on: Boolean) {
        if (on) {
            t.text = "✔"
            t.setTextColor(Color.WHITE)
            t.background = oval(C.GREEN)
        } else {
            t.text = ""
            t.setTextColor(Color.WHITE)
            t.background = oval(Color.WHITE, C.col("#9AA39D"), 2)
        }
    }

    private fun styleCell(t: TextView, on: Boolean, color: Int) {
        if (on) {
            t.background = bg(color, 24)
            t.setTextColor(Color.WHITE)
        } else {
            t.background = bg(C.GRAY, 24)
            t.setTextColor(C.MUTED)
        }
    }

    /** A grid of numbered toggle cells (1..count). */
    protected fun grid(
        parent: LinearLayout,
        count: Int,
        cols: Int,
        isOn: (Int) -> Boolean,
        toggle: (Int) -> Boolean,
        onColor: Int,
        after: () -> Unit
    ) {
        var i = 1
        while (i <= count) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (c in 0 until cols) {
                val idx = i + c
                val cell: View
                if (idx <= count) {
                    val t = tv(idx.toString(), 15f, Color.WHITE, true)
                    styleCell(t, isOn(idx), onColor)
                    t.setOnClickListener {
                        styleCell(t, toggle(idx), onColor)
                        after()
                    }
                    cell = t
                } else {
                    cell = View(this)
                }
                row.addView(cell, lp(0, dp(46), 1f).margins(dp(4), dp(4), dp(4), dp(4)))
            }
            parent.addView(row, lp(MATCH, WRAP))
            i += cols
        }
    }

    protected fun stepper(
        parent: LinearLayout,
        label: String,
        color: Int,
        get: () -> Int,
        set: (Int) -> Boolean,
        onChange: () -> Unit
    ) {
        val c = card(parent)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL
        c.addView(tv(label, 15f, C.TEXT, true, Gravity.START or Gravity.CENTER_VERTICAL), lp(0, WRAP, 1f))
        val v = tv(get().toString(), 20f, color, true)
        val minus = tv("−", 22f, Color.WHITE, true)
        minus.background = bg(color, 20)
        val plus = tv("+", 22f, Color.WHITE, true)
        plus.background = bg(color, 20)
        minus.setOnClickListener {
            if (set(get() - 1)) {
                v.text = get().toString()
                onChange()
            }
        }
        plus.setOnClickListener {
            if (set(get() + 1)) {
                v.text = get().toString()
                onChange()
            }
        }
        c.addView(plus, lp(dp(40), dp(40)))
        c.addView(v, lp(dp(56), WRAP))
        c.addView(minus, lp(dp(40), dp(40)))
    }

    protected fun progress(parent: LinearLayout, label: String, value: Int, maxV: Int, color: Int) {
        val c = card(parent)
        c.addView(tv("$label:  $value / $maxV", 14f, C.TEXT, true, Gravity.START or Gravity.CENTER_VERTICAL))
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = max(1, maxV)
        pb.progress = value
        pb.progressTintList = ColorStateList.valueOf(color)
        c.addView(pb, lp(MATCH, dp(10)).margins(0, dp(8), 0, 0))
    }

    protected fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
