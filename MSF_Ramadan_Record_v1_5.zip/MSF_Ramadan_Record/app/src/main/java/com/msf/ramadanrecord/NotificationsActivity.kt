package com.msf.ramadanrecord

import android.Manifest
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.SwitchCompat

class NotificationsActivity : BaseActivity() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        Reminders.scheduleAll(this)
        render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onRestart() {
        super.onRestart()
        render()
    }

    private fun askPermission() {
        if (Build.VERSION.SDK_INT >= 33 && Store.getStr(this, "perm_asked").isEmpty()) {
            Store.putStr(this, "perm_asked", "1")
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            i.putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(i)
        }
    }

    private fun render() {
        val content = screen("اطلاعات کی ترتیبات", 10)
        Reminders.ensureChannels(this)

        if (!Reminders.canPost(this)) {
            val c = card(content, C.HIGHLIGHT)
            c.addView(tv("نوٹیفکیشن کی اجازت بند ہے۔ یاد دہانیاں دیکھنے کے لیے اجازت دیں۔", 13f, C.TEXT, true))
            c.addView(button("اجازت دیں", C.GREEN) { askPermission() }, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))
        }

        heading(content, "روزانہ کی یاد دہانیاں")
        for (i in 0 until Reminders.COUNT) reminderCard(content, i)

        addButton(content, "ٹیسٹ نوٹیفکیشن بھیجیں", C.BLUE) {
            if (Reminders.canPost(this)) {
                Reminders.show(this, 2)
                toast("ٹیسٹ نوٹیفکیشن بھیج دیا گیا")
            } else {
                askPermission()
            }
        }
        val note = card(content, C.col("#E8F2DC"))
        note.addView(tv("آواز اور کمپن سیٹنگز کی مرکزی اسکرین سے آن آف کی جا سکتی ہے۔", 12f, C.TEXT))
    }

    private fun reminderCard(parent: LinearLayout, i: Int) {
        val c = card(parent)
        c.orientation = LinearLayout.HORIZONTAL
        c.gravity = Gravity.CENTER_VERTICAL

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(Reminders.TITLES[i], 15f, C.TEXT, true, Gravity.START or Gravity.CENTER_VERTICAL))
        col.addView(tv(Reminders.SUBS[i], 12f, C.MUTED, false, Gravity.START or Gravity.CENTER_VERTICAL))
        c.addView(col, lp(0, WRAP, 1f))

        val mins = Store.remMin(this, i)
        val time = tv(Dates.fmtTime(mins), 14f, Color.WHITE, true)
        time.background = bg(Color.parseColor("#14573F"), 14)
        time.setPadding(dp(12), dp(8), dp(12), dp(8))
        time.setOnClickListener {
            TimePickerDialog(this, { _, h, m ->
                Store.setRemMin(this, i, h * 60 + m)
                Reminders.schedule(this, i)
                render()
            }, mins / 60, mins % 60, false).show()
        }
        c.addView(time, lp(WRAP, WRAP).margins(dp(6), 0, dp(6), 0))

        val sw = SwitchCompat(this)
        sw.isChecked = Store.remOn(this, i)
        sw.setOnCheckedChangeListener { _, on ->
            Store.setRemOn(this, i, on)
            Reminders.schedule(this, i)
            if (on && !Reminders.canPost(this)) toast("پہلے نوٹیفکیشن کی اجازت دیں")
        }
        c.addView(sw, lp(WRAP, WRAP))
    }
}
