package com.msf.ramadanrecord

import android.content.Context
import android.graphics.Typeface

object Fonts {
    class F(val label: String, val file: String)

    /** file = "" means the phone's default font */
    val ALL = listOf(
        F("ڈیفالٹ (فون کا فونٹ)", ""),
        F("جمیل نوری نستعلیق", "jameel_noori_nastaleeq.ttf"),
        F("القلم قرآن", "al_qalam_quran.ttf"),
        F("القلم قرآن 2", "al_qalam_quran_2.ttf"),
        F("القلم قرآن 2A", "al_qalam_quran_2a.ttf"),
        F("القلم قرآن مجید", "al_qalam_quran_majeed.ttf"),
        F("القلم قرآن مجید 1", "al_qalam_quran_majeed_1.ttf"),
        F("القلم قرآن مجید 2", "al_qalam_quran_majeed_2.ttf"),
        F("القلم کولکتہ قرآنی", "al_qalam_kolkata.ttf"),
        F("المجید قرآنی", "al_majeed_quranic.ttf"),
        F("المصحف قرآن", "al_mushaf_quran.ttf"),
        F("نورِ قرآن", "noor_e_quran.ttf")
    )

    private val cache = HashMap<String, Typeface>()

    /** currently selected font file ("" = default) */
    @JvmField var file: String = ""

    /** typeface used by every text in the app (null = default) */
    @JvmField var active: Typeface? = null

    fun load(c: Context, f: String): Typeface? {
        if (f.isEmpty()) return null
        cache[f]?.let { return it }
        return try {
            val t = Typeface.createFromAsset(c.assets, "fonts/$f")
            cache[f] = t
            t
        } catch (e: Exception) {
            null
        }
    }

    fun init(c: Context) {
        file = Store.getStr(c, "font_file")
        active = load(c, file)
    }

    fun set(c: Context, f: String) {
        Store.putStr(c, "font_file", f)
        file = f
        active = load(c, f)
    }

    fun labelOf(f: String): String = ALL.firstOrNull { it.file == f }?.label ?: ALL[0].label
}
