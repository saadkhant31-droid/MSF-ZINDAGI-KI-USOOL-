package com.msf.ramadanrecord

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate
import kotlin.math.max

class FastsActivity : BaseActivity() {

    // filter: -1 all, 0 kept, 1 not kept, 2 travel, 3 illness, 4 other
    private var filter = -1
    private var page = 0
    private val perPage = 10
    private val colW = intArrayOf(40, 112, 62, 62, 52, 124, 62, 84, 70, 130, 44)  // dp, right-to-left
    private val reasonLabels = arrayOf("—", "سفر", "بیماری", "دیگر")
    private val filterLabels = arrayOf("تمام روزے", "رکھے گئے روزے", "نہیں رکھے گئے", "سفر کی وجہ سے", "بیماری کی وجہ سے", "دیگر وجوہات")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private class Day(val n: Int, val date: LocalDate, val rec: FardRec) {
        val cat: Int
            get() = if (!rec.recorded) -1 else if (rec.kept) 0 else when (rec.reason) {
                1 -> 2
                2 -> 3
                3 -> 4
                else -> 1
            }
    }

    private fun render() {
        val content = heroScreen("رمضان کے فرض روزے", "اللہ کے لیے رکھے گئے روزے، قبول ہوں، آمین", 3)
        val total = Store.totalDays(this)
        val start = Store.startDate(this)
        val off = Store.offset(this)
        val today = LocalDate.now()
        val days = (1..total).map { Day(it, start.plusDays((it - 1).toLong()), Store.fardRec(this, it)) }

        content.addView(tabs(), lp(MATCH, WRAP))

        // ---- summary ----
        val cnt = IntArray(5)
        for (d in days) if (d.cat >= 0) cnt[d.cat]++
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL

        val rm = LinearLayout(this)
        rm.orientation = LinearLayout.VERTICAL
        rm.gravity = Gravity.CENTER
        rm.background = bg(C.col("#0C4A2C"), 14, C.GOLD, 1)
        rm.setPadding(dp(6), dp(10), dp(6), dp(10))
        rm.addView(tv("🕌", 22f, Color.WHITE))
        rm.addView(tv("رمضان المبارک", 12f, C.GOLD, true))
        rm.addView(tv(start.year.toString(), 15f, Color.WHITE, true))
        rm.addView(tv("کل روزے: $total", 12f, Color.WHITE, true))
        top.addView(rm, lp(0, MATCH, 1.1f).margins(dp(3), 0, dp(3), 0))

        val tiles = LinearLayout(this)
        tiles.orientation = LinearLayout.HORIZONTAL
        val defs = listOf(
            Triple("✔", "رکھے گئے روزے", cnt[0]) to C.col("#1E8E6A"),
            Triple("✖", "نہیں رکھے گئے", cnt[1]) to C.RED,
            Triple("⚠", "سفر کی وجہ سے نہیں رکھے", cnt[2]) to C.col("#E0A21B"),
            Triple("➕", "بیماری کی وجہ سے نہیں رکھے", cnt[3]) to C.PURPLE,
            Triple("⋯", "دیگر وجوہات", cnt[4]) to C.BLUE
        )
        for ((i, p) in defs.withIndex()) {
            val (t, color) = p
            val tile = summaryTile(t.first, t.second, t.third.toString(), color) {
                filter = if (filter == i) -1 else i
                page = 0
                render()
            }
            tiles.addView(tile, lp(0, WRAP, 1f).margins(dp(2), 0, dp(2), 0))
        }
        top.addView(tiles, lp(0, WRAP, 4.4f))
        content.addView(top, lp(MATCH, WRAP).margins(0, dp(8), 0, 0))

        // ---- qaza remaining ----
        val qBox = LinearLayout(this)
        qBox.orientation = LinearLayout.HORIZONTAL
        qBox.gravity = Gravity.CENTER_VERTICAL
        qBox.background = bg(C.col("#EAF2E3"), 14, C.BORDER, 1)
        qBox.setPadding(dp(14), dp(10), dp(14), dp(10))
        val qRem = max(0, Store.qazaTotal(this) - Store.qazaDone(this))
        val qInfo = LinearLayout(this)
        qInfo.orientation = LinearLayout.VERTICAL
        qInfo.addView(tv("قضا روزوں کا حساب:", 12f, C.DARK, true, Gravity.START))
        qInfo.addView(tv("باقی قضا روزے = کل قضا روزے - ادا کیے گئے قضا روزے", 11f, C.MUTED, false, Gravity.START))
        qBox.addView(qInfo, lp(0, WRAP, 1f))
        qBox.addView(tv("باقی قضا روزے", 12f, C.DARK, true), lp(WRAP, WRAP).margins(dp(8), 0, dp(8), 0))
        qBox.addView(tv(qRem.toString(), 26f, C.DARK, true))
        qBox.setOnClickListener { go(QazaActivity::class.java) }
        content.addView(qBox, lp(MATCH, WRAP).margins(dp(4), dp(8), dp(4), 0))

        // ---- table ----
        val shown = days.filter { filter < 0 || it.cat == filter }
        val pages = max(1, (shown.size + perPage - 1) / perPage)
        if (page >= pages) page = pages - 1
        if (page < 0) page = 0

        val pager = LinearLayout(this)
        pager.orientation = LinearLayout.HORIZONTAL
        pager.gravity = Gravity.CENTER_VERTICAL
        pager.background = bg(C.GREEN, 18, C.GOLD, 1)
        val prev = tv("›", 22f, Color.WHITE, true)
        prev.setPadding(dp(12), 0, dp(12), dp(2))
        prev.setOnClickListener { if (page > 0) { page--; render() } }
        val next = tv("‹", 22f, Color.WHITE, true)
        next.setPadding(dp(12), 0, dp(12), dp(2))
        next.setOnClickListener { if (page < pages - 1) { page++; render() } }
        pager.addView(prev)
        pager.addView(tv("رمضان ${start.year} • ${page + 1}/$pages", 12f, Color.WHITE, true))
        pager.addView(next)
        content.addView(sectionBar("📅 روزوں کا مکمل ریکارڈ", pager), lp(MATCH, WRAP).margins(dp(4), dp(12), dp(4), 0))

        if (filter >= 0) {
            val f = tv("فلٹر: ${filterLabels[filter + 1]}  (ہٹانے کے لیے یہاں ٹیپ کریں)", 11f, C.DARK, true)
            f.background = bg(C.HIGHLIGHT, 10, C.GOLD, 1)
            f.setPadding(dp(10), dp(6), dp(10), dp(6))
            f.setOnClickListener { filter = -1; page = 0; render() }
            content.addView(f, lp(MATCH, WRAP).margins(dp(4), dp(6), dp(4), 0))
        }

        val heads = arrayOf("نمبر", "تاریخ", "دن", "مہینہ", "سال", "اسلامی تاریخ", "رمضان دن", "روزہ رکھا؟", "وجہ", "نوٹ", "ترمیم")
        val (hs, tbl) = tableShell(heads, colW)
        val hYear = Dates.hijriYear(start, off)
        val slice = shown.drop(page * perPage).take(perPage)
        if (slice.isEmpty()) {
            tbl.addView(tv("اس فلٹر میں کوئی روزہ نہیں ہے۔", 13f, C.MUTED).also { it.setPadding(dp(16), dp(20), dp(16), dp(20)) })
        }
        var n = 0
        for (d in slice) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setBackgroundColor(
                if (d.date == today) C.HIGHLIGHT
                else if (n % 2 == 0) C.col("#F4F7EE") else Color.WHITE
            )
            row.setPadding(0, dp(8), 0, dp(8))
            n++

            row.addView(cellBox(colW[0], tv(d.n.toString(), 12f, C.TEXT)))
            row.addView(cellBox(colW[1], tv(Dates.greg(d.date), 12f, C.TEXT)))
            row.addView(cellBox(colW[2], tv(Dates.urduDay(d.date), 12f, C.TEXT)))
            row.addView(cellBox(colW[3], tv(Dates.gMonths[d.date.monthValue - 1], 12f, C.TEXT)))
            row.addView(cellBox(colW[4], tv(d.date.year.toString(), 12f, C.TEXT)))
            row.addView(cellBox(colW[5], tv("${d.n} رمضان $hYear" + "ھ", 12f, C.TEXT)))
            row.addView(cellBox(colW[6], tv(d.n.toString(), 12f, C.TEXT)))

            val st = when {
                !d.rec.recorded -> pill("باقی", C.col("#9AA39D"))
                d.rec.kept -> pill("رکھا", C.GREEN)
                else -> pill("نہیں رکھا", C.RED)
            }
            st.setOnClickListener { editDialog(d.n, d.date) }
            row.addView(cellBox(colW[7], st))

            row.addView(cellBox(colW[8], tv(if (d.rec.kept || !d.rec.recorded) "—" else reasonLabels[d.rec.reason.coerceIn(0, 3)], 12f, C.TEXT)))

            val nt = tv(if (d.rec.note.isEmpty()) "-" else d.rec.note, 11f, C.TEXT, false, Gravity.START or Gravity.CENTER_VERTICAL)
            nt.maxLines = 3
            nt.layoutParams = LinearLayout.LayoutParams(dp(colW[9]), WRAP)
            nt.setPadding(dp(6), 0, dp(6), 0)
            row.addView(nt)

            val ed = tv("✏️", 17f, Color.BLACK)
            ed.setPadding(dp(8), dp(4), dp(8), dp(4))
            ed.setOnClickListener { editDialog(d.n, d.date) }
            row.addView(cellBox(colW[10], ed))

            tbl.addView(row)
        }
        content.addView(hs, lp(MATCH, WRAP).margins(dp(4), dp(6), dp(4), 0))

        // ---- footer chips ----
        val foot = LinearLayout(this)
        foot.orientation = LinearLayout.HORIZONTAL
        val fdefs = listOf(
            "رکھے گئے" to cnt[0], "نہیں رکھے گئے" to cnt[1], "سفر" to cnt[2], "بیماری" to cnt[3], "دیگر وجوہات" to cnt[4]
        )
        val fcolors = intArrayOf(C.GREEN, C.RED, C.col("#E0A21B"), C.PURPLE, C.BLUE)
        for (i in fdefs.indices) {
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(C.SURFACE, 12, fcolors[i], 1)
            c.setPadding(dp(2), dp(6), dp(2), dp(6))
            c.addView(tv(fdefs[i].first, 10f, fcolors[i], true))
            c.addView(tv(fdefs[i].second.toString(), 18f, fcolors[i], true))
            foot.addView(c, lp(0, WRAP, 1f).margins(dp(2), 0, dp(2), 0))
        }
        content.addView(foot, lp(MATCH, WRAP).margins(dp(2), dp(8), dp(2), 0))

        val note = card(content, C.col("#E8F2DC"))
        note.addView(tv("ہدایت: کسی دن کے \"روزہ رکھا؟\" بٹن یا ✏️ پر ٹیپ کر کے رکھا / نہیں رکھا اور وجہ درج کریں۔ اوپر کے رنگین خانوں پر ٹیپ کرنے سے وہی روزے الگ دکھائے جاتے ہیں۔ نہیں رکھے گئے روزے کو قضا روزوں میں بھی شامل کیا جا سکتا ہے۔", 12f, C.TEXT, false, Gravity.START))
    }

    // ---------- top tab buttons ----------
    private fun tabs(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val defs = listOf("📅" to "فرض روزے", "🗓" to "روزے کی تفصیل", "⏱" to "روزانہ کا ریکارڈ", "📋" to "رپورٹ", "📝" to "نوٹس")
        for (i in defs.indices) {
            val sel = (i == 0 && filter < 0) || (i == 1 && filter >= 0)
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL
            c.gravity = Gravity.CENTER
            c.background = bg(if (sel) C.DARK else C.col("#FFFDF5"), 14, C.BORDER, 1)
            c.setPadding(dp(2), dp(8), dp(2), dp(8))
            c.addView(tv(defs[i].first, 20f, if (sel) Color.WHITE else C.DARK))
            val l = tv(defs[i].second, 10f, if (sel) Color.WHITE else C.DARK, true)
            l.minLines = 2
            l.maxLines = 2
            c.addView(l)
            c.setOnClickListener {
                when (i) {
                    0 -> { filter = -1; page = 0; render() }
                    1 -> showFilterMenu(c)
                    2 -> go(CalendarActivity::class.java)
                    3 -> go(ReportsActivity::class.java)
                    else -> go(NotesActivity::class.java)
                }
            }
            row.addView(c, lp(0, WRAP, 1f).margins(dp(2), 0, dp(2), 0))
        }
        return row
    }

    private fun showFilterMenu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        for (i in filterLabels.indices) pm.menu.add(0, i, i, filterLabels[i])
        pm.setOnMenuItemClickListener { item ->
            filter = item.itemId - 1
            page = 0
            render()
            true
        }
        pm.show()
    }

    // ---------- edit dialog ----------
    private fun editDialog(dayNo: Int, date: LocalDate) {
        val rec = Store.fardRec(this, dayNo)

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.layoutDirection = View.LAYOUT_DIRECTION_RTL
        box.setPadding(dp(20), dp(8), dp(20), 0)

        box.addView(tv("${Dates.urduDay(date)} • ${Dates.greg(date)}", 13f, C.MUTED, true, Gravity.START))

        box.addView(fieldLabel("روزہ رکھا؟"))
        val statusSp = spinnerOf(arrayOf("رکھا", "نہیں رکھا", "ریکارڈ صاف کریں"), if (rec.kept) 0 else if (rec.recorded) 1 else 0)
        box.addView(statusSp, lp(MATCH, WRAP))

        box.addView(fieldLabel("نہ رکھنے کی وجہ (صرف \"نہیں رکھا\" کی صورت میں)"))
        val reasonSp = spinnerOf(arrayOf("کوئی خاص وجہ نہیں", "سفر", "بیماری", "دیگر وجہ"), rec.reason.coerceIn(0, 3))
        box.addView(reasonSp, lp(MATCH, WRAP))

        box.addView(fieldLabel("نوٹ"))
        val noteEt = EditText(this)
        noteEt.setText(rec.note)
        noteEt.minLines = 2
        noteEt.textSize = 13f
        noteEt.gravity = Gravity.TOP or Gravity.START
        box.addView(noteEt, lp(MATCH, WRAP))

        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)

        AlertDialog.Builder(this)
            .setTitle("رمضان کا $dayNo واں روزہ")
            .setView(scroll)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                val status = statusSp.selectedItemPosition
                val reason = reasonSp.selectedItemPosition
                Store.setFard(this, dayNo, status, reason, noteEt.text.toString().trim())
                render()
                if (status == 1) offerQaza(dayNo, date, reason)
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun offerQaza(dayNo: Int, date: LocalDate, reason: Int) {
        val list = Store.qazas(this)
        if (list.any { it.src == dayNo }) return
        AlertDialog.Builder(this)
            .setMessage("کیا اس روزے کو قضا روزوں میں شامل کریں؟")
            .setPositiveButton("ہاں، شامل کریں") { _, _ ->
                val qReason = when (reason) {
                    1 -> 1
                    2 -> 0
                    else -> 3
                }
                list.add(QazaRec(date.toString(), qReason, false, "رمضان کا $dayNo واں روزہ", dayNo))
                Store.saveQazas(this, list)
                toast("قضا روزوں میں شامل ہو گیا")
                render()
            }
            .setNegativeButton("نہیں", null)
            .show()
    }
}
