package com.msf.ramadanrecord

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView

/** A fixed-width table cell that centres its child. */
fun Context.cellBox(wDp: Int, v: View): View {
    val box = LinearLayout(this)
    box.gravity = Gravity.CENTER
    box.addView(v)
    box.layoutParams = LinearLayout.LayoutParams(dp(wDp), WRAP)
    return box
}

fun Context.pill(text: String, color: Int, sizeSp: Float = 12f): TextView {
    val t = tv(text, sizeSp, Color.WHITE, true)
    t.setPadding(dp(12), dp(4), dp(12), dp(4))
    t.background = bg(color, 8)
    return t
}

/** Coloured summary tile: icon, label, big value. */
fun Context.summaryTile(icon: String, label: String, value: String, color: Int, onClick: (() -> Unit)? = null): LinearLayout {
    val c = LinearLayout(this)
    c.orientation = LinearLayout.VERTICAL
    c.gravity = Gravity.CENTER
    c.background = bg(color, 14)
    c.setPadding(dp(2), dp(10), dp(2), dp(10))
    c.addView(tv(icon, 22f, Color.WHITE))
    val l = tv(label, 10f, Color.WHITE)
    l.minLines = 2
    l.maxLines = 2
    c.addView(l)
    c.addView(tv(value, if (value.length > 4) 13f else 24f, Color.WHITE, true))
    if (onClick != null) c.setOnClickListener { onClick() }
    return c
}

/** Dark green section title bar with an optional trailing view (button / pager). */
fun Context.sectionBar(title: String, trailing: View?): View {
    val bar = LinearLayout(this)
    bar.orientation = LinearLayout.HORIZONTAL
    bar.gravity = Gravity.CENTER_VERTICAL
    bar.background = bg(C.DARK, 14)
    bar.setPadding(dp(14), dp(10), dp(14), dp(10))
    bar.addView(tv(title, 15f, Color.WHITE, true, Gravity.START or Gravity.CENTER_VERTICAL), lp(0, WRAP, 1f))
    if (trailing != null) bar.addView(trailing, lp(WRAP, WRAP))
    return bar
}

fun Context.spinnerOf(items: Array<String>, selected: Int): Spinner {
    val s = Spinner(this)
    s.adapter = ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items)
    s.setSelection(selected)
    return s
}

fun Context.fieldLabel(text: String): TextView {
    val t = tv(text, 12f, C.MUTED, true, Gravity.START)
    t.setPadding(0, dp(10), 0, dp(2))
    return t
}

/** Table with header row; rows are added by the caller. */
fun Context.tableShell(heads: Array<String>, colW: IntArray): Pair<android.widget.HorizontalScrollView, LinearLayout> {
    val hs = android.widget.HorizontalScrollView(this)
    val tbl = LinearLayout(this)
    tbl.orientation = LinearLayout.VERTICAL
    tbl.background = bg(C.SURFACE, 12, C.BORDER, 1)
    hs.addView(tbl)
    val hr = LinearLayout(this)
    hr.orientation = LinearLayout.HORIZONTAL
    hr.setBackgroundColor(C.col("#EAF2E3"))
    hr.setPadding(0, dp(10), 0, dp(10))
    for (i in heads.indices) hr.addView(cellBox(colW[i], tv(heads[i], 11f, C.DARK, true)))
    tbl.addView(hr)
    return Pair(hs, tbl)
}

/** Simple grouped bar chart drawn on a Canvas. */
class BarChartView(ctx: Context) : View(ctx) {
    var labels: List<String> = emptyList()
    var series: List<Pair<Int, IntArray>> = emptyList()  // colour, value per label
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val n = labels.size
        if (n == 0 || series.isEmpty()) return
        val w = width.toFloat()
        val h = height.toFloat()
        val left = context.dp(26).toFloat()
        val top = context.dp(8).toFloat()
        val bottom = h - context.dp(22)
        var maxV = 1
        for (s in series) for (v in s.second) if (v > maxV) maxV = v
        val step = if (maxV <= 5) 1 else Math.ceil(maxV / 4.0).toInt()
        val topVal = step * Math.ceil(maxV.toDouble() / step).toInt()
        val chartH = bottom - top

        paint.textSize = context.dp(10).toFloat()
        paint.textAlign = android.graphics.Paint.Align.RIGHT
        var g = 0
        while (g <= topVal) {
            val y = bottom - chartH * g / topVal
            paint.color = C.col("#DDE3D8")
            paint.strokeWidth = 1f
            canvas.drawLine(left, y, w - context.dp(4), y, paint)
            paint.color = C.col("#55605A")
            canvas.drawText(g.toString(), left - context.dp(4), y + context.dp(4), paint)
            g += step
        }

        val slot = (w - left - context.dp(6)) / n
        val sc = series.size
        var barW = slot * 0.8f / sc
        val maxBar = context.dp(18).toFloat()
        if (barW > maxBar) barW = maxBar
        val groupW = barW * sc
        val skip = Math.ceil(n / 8.0).toInt().coerceAtLeast(1)
        paint.textAlign = android.graphics.Paint.Align.CENTER
        for (i in 0 until n) {
            val gx = left + slot * i + (slot - groupW) / 2f
            for (j in 0 until sc) {
                val v = series[j].second[i]
                if (v > 0) {
                    paint.color = series[j].first
                    val y = bottom - chartH * v / topVal
                    canvas.drawRect(gx + barW * j, y, gx + barW * (j + 1) - 1f, bottom, paint)
                }
            }
            if (i % skip == 0) {
                paint.color = C.col("#55605A")
                canvas.drawText(labels[i], left + slot * i + slot / 2f, h - context.dp(6), paint)
            }
        }
    }
}
