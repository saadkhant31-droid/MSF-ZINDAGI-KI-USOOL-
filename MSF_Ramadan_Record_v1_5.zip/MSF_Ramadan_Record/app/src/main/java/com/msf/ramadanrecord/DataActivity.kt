package com.msf.ramadanrecord

import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import java.time.LocalDate

class DataActivity : BaseActivity() {

    private val saver = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            try {
                contentResolver.openOutputStream(uri)?.use {
                    it.write(Store.exportJson(this).toByteArray(Charsets.UTF_8))
                }
                toast("بیک اپ محفوظ ہو گیا")
            } catch (e: Exception) {
                toast("بیک اپ محفوظ نہیں ہو سکا")
            }
        }
    }

    private val opener = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = try {
                contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
            } catch (e: Exception) {
                null
            }
            if (text == null) {
                toast("فائل نہیں کھل سکی")
            } else {
                AlertDialog.Builder(this)
                    .setTitle("بیک اپ بحال کریں؟")
                    .setMessage("موجودہ ریکارڈ بیک اپ کے ریکارڈ سے بدل جائے گا۔")
                    .setPositiveButton("بحال کریں") { _, _ ->
                        if (Store.importJson(this, text)) {
                            Reminders.scheduleAll(this)
                            toast("بیک اپ بحال ہو گیا")
                            recreate()
                        } else {
                            toast("یہ اس ایپ کی درست بیک اپ فائل نہیں ہے")
                        }
                    }
                    .setNegativeButton("منسوخ", null)
                    .show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun render() {
        val content = screen("ڈیٹا کا بیک اپ", 10)

        heading(content, "بیک اپ")
        settingRow(content, R.drawable.ic_backup, "بیک اپ بنائیں", "روزے، نمازیں، قرآن اور نوٹس فائل میں محفوظ کریں", hMargin = 14) {
            saver.launch("MSF_Ramadan_Backup_${LocalDate.now()}.json")
        }
        settingRow(content, R.drawable.ic_doc, "بیک اپ بحال کریں", "پہلے سے محفوظ کی ہوئی فائل سے ریکارڈ واپس لائیں", hMargin = 14) {
            opener.launch(arrayOf("*/*"))
        }

        heading(content, "ڈیٹا")
        addButton(content, "تمام ریکارڈ مٹائیں", C.RED) {
            AlertDialog.Builder(this)
                .setTitle("تمام ریکارڈ مٹائیں؟")
                .setMessage("روزے، نمازیں، قرآن، نوٹس اور سیٹنگز سب ختم ہو جائیں گی۔")
                .setPositiveButton("مٹائیں") { _, _ ->
                    Store.resetAll(this)
                    java.io.File(filesDir, "profile.jpg").delete()
                    Reminders.scheduleAll(this)
                    toast("ریکارڈ مٹا دیا گیا")
                    recreate()
                }
                .setNegativeButton("منسوخ", null)
                .show()
        }
        val note = card(content, C.col("#E8F2DC"))
        note.addView(tv("بیک اپ فائل میں آپ کا پن شامل نہیں ہوتا۔ فائل کو محفوظ جگہ رکھیں۔", 12f, C.TEXT))
    }
}
