package com.msf.ramadanrecord

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.widget.SwitchCompat

object AppInfo {
    /** Change this to your real support address. */
    const val SUPPORT_EMAIL = "support@example.com"
    const val SHARE_TEXT = "MSF RamdanulMubarak Record - رمضان المبارک کا ریکارڈ رکھنے والی ایپ"
}

/** One settings row: round icon (right), title + subtitle, optional chip / switch, chevron (left). */
fun Activity.settingRow(
    parent: LinearLayout,
    icon: Int,
    title: String,
    sub: String,
    chip: String? = null,
    switchOn: Boolean? = null,
    hMargin: Int = 4,
    onClick: () -> Unit
): LinearLayout {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    row.gravity = Gravity.CENTER_VERTICAL
    row.background = bg(C.CARD, 16, C.BORDER, 1)
    row.setPadding(dp(12), dp(10), dp(12), dp(10))
    row.isClickable = true
    row.setOnClickListener { onClick() }

    val ic = ImageView(this)
    ic.setImageResource(icon)
    ic.setPadding(dp(12), dp(12), dp(12), dp(12))
    ic.background = oval(Color.parseColor("#0D4A35"), C.GOLD, 1)
    row.addView(ic, lp(dp(48), dp(48)))

    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.addView(tv(title, 16f, C.TEXT, true, Gravity.START or Gravity.CENTER_VERTICAL))
    col.addView(tv(sub, 12f, C.MUTED, false, Gravity.START or Gravity.CENTER_VERTICAL))
    row.addView(col, lp(0, WRAP, 1f).margins(dp(8), 0, dp(12), 0))

    if (chip != null) {
        val t = tv(chip, 13f, Color.WHITE, true)
        t.background = bg(Color.parseColor("#14573F"), 16)
        t.setPadding(dp(14), dp(6), dp(14), dp(6))
        row.addView(t, lp(WRAP, WRAP).margins(dp(4), 0, dp(4), 0))
    }
    if (switchOn != null) {
        val sw = SwitchCompat(this)
        sw.isChecked = switchOn
        sw.isClickable = false
        sw.isFocusable = false
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, Color.parseColor("#E6E6E6")))
        sw.trackTintList = ColorStateList(states, intArrayOf(C.GREEN, Color.parseColor("#8E9892")))
        row.addView(sw, lp(WRAP, WRAP))
    } else {
        val ch = ImageView(this)
        ch.setImageResource(R.drawable.ic_chev)
        ch.setColorFilter(C.MUTED)
        row.addView(ch, lp(dp(24), dp(24)).margins(dp(4), 0, 0, 0))
    }
    parent.addView(row, lp(MATCH, WRAP).margins(dp(hMargin), dp(5), dp(hMargin), dp(5)))
    return row
}

fun Activity.inputField(hint: String, text: String, type: Int = InputType.TYPE_CLASS_TEXT): EditText {
    val e = EditText(this)
    e.hint = hint
    e.setText(text)
    e.inputType = type
    Fonts.active?.let { e.typeface = it }
    e.setTextColor(C.TEXT)
    e.setHintTextColor(C.MUTED)
    e.textSize = 15f
    e.gravity = Gravity.START or Gravity.CENTER_VERTICAL
    e.background = bg(C.CARD, 12, C.BORDER, 1)
    e.setPadding(dp(14), dp(10), dp(14), dp(10))
    return e
}
