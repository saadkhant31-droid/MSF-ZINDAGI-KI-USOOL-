package com.msf.ramadanrecord

import java.time.LocalDate
import java.time.chrono.HijrahDate
import java.time.format.TextStyle
import java.time.temporal.ChronoField
import java.util.Locale

object Dates {
    val gMonths = arrayOf(
        "جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
        "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"
    )
    val hMonths = arrayOf(
        "محرم", "صفر", "ربیع الاول", "ربیع الثانی", "جمادی الاول", "جمادی الثانی",
        "رجب", "شعبان", "رمضان", "شوال", "ذوالقعدہ", "ذوالحجہ"
    )
    val urduDays = arrayOf("پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ", "اتوار")
    val prayers = arrayOf("فجر", "ظہر", "عصر", "مغرب", "عشاء")

    fun greg(d: LocalDate): String = "${d.dayOfMonth} ${gMonths[d.monthValue - 1]} ${d.year}"

    fun eng(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale.ENGLISH)

    fun urduDay(d: LocalDate): String = urduDays[d.dayOfWeek.value - 1]

    fun hijri(d: LocalDate, offset: Int): String {
        return try {
            val h = HijrahDate.from(d.plusDays(offset.toLong()))
            val day = h.get(ChronoField.DAY_OF_MONTH)
            val month = h.get(ChronoField.MONTH_OF_YEAR)
            val year = h.get(ChronoField.YEAR)
            "$day ${hMonths[month - 1]} ${year}ھ"
        } catch (e: Exception) {
            "-"
        }
    }

    fun hijriYear(d: LocalDate, offset: Int): Int {
        return try {
            HijrahDate.from(d.plusDays(offset.toLong())).get(ChronoField.YEAR)
        } catch (e: Exception) {
            0
        }
    }

    fun fmtTime(min: Int): String {
        val h24 = min / 60
        val m = min % 60
        val ap = if (h24 >= 12) "PM" else "AM"
        var h = h24 % 12
        if (h == 0) h = 12
        return String.format(Locale.US, "%02d:%02d %s", h, m, ap)
    }
}
