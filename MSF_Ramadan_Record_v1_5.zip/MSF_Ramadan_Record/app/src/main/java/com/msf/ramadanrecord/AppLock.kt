package com.msf.ramadanrecord

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

object AppLock {
    private const val TIMEOUT_MS = 30_000L

    var unlocked = false
    var lastStop = 0L

    @Volatile
    var showing = false

    fun stopped() {
        lastStop = System.currentTimeMillis()
    }

    fun unlockNow() {
        unlocked = true
        lastStop = Long.MAX_VALUE / 2
    }

    fun check(a: Activity) {
        if (a is LockActivity || showing) return
        if (!Store.lockOn(a) || Store.pinHash(a).isEmpty()) return
        val now = System.currentTimeMillis()
        if (!unlocked || now - lastStop > TIMEOUT_MS) {
            unlocked = false
            showing = true
            a.startActivity(Intent(a, LockActivity::class.java))
        }
    }
}

class LockActivity : AppCompatActivity() {
    private var entered = ""
    private lateinit var dots: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        C.dark = Store.darkMode(this)
        super.onCreate(savedInstanceState)
        AppLock.showing = true
        window.statusBarColor = C.DARK

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#05241A"), Color.parseColor("#0E5A3A"))
        )
        root.setPadding(dp(24), dp(24), dp(24), dp(24))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.logo)
        root.addView(logo, lp(dp(110), dp(110)))
        root.addView(tv("ایپ لاک ہے", 22f, Color.WHITE, true), lp(WRAP, WRAP).margins(0, dp(10), 0, 0))
        root.addView(tv("اپنا 4 ہندسوں کا پن لکھیں", 13f, Color.parseColor("#F3E3A5")), lp(WRAP, WRAP).margins(0, dp(4), 0, 0))

        dots = tv("", 34f, Color.WHITE, true)
        root.addView(dots, lp(WRAP, WRAP).margins(0, dp(14), 0, dp(14)))

        val rows = listOf(
            listOf("1", "2", "3"),
            listOf("4", "5", "6"),
            listOf("7", "8", "9"),
            listOf("", "0", "⌫")
        )
        for (r in rows) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            for (k in r) {
                val b = tv(k, 26f, Color.WHITE, true)
                if (k.isNotEmpty()) {
                    b.background = oval(Color.parseColor("#14573F"), C.GOLD, 1)
                    b.setOnClickListener { press(k) }
                }
                line.addView(b, lp(dp(72), dp(72)).margins(dp(10), dp(6), dp(10), dp(6)))
            }
            root.addView(line, lp(WRAP, WRAP))
        }

        val forgot = tv("پن بھول گئے؟", 14f, Color.parseColor("#F3E3A5"))
        forgot.setPadding(dp(16), dp(14), dp(16), dp(14))
        forgot.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("پن بھول گئے؟")
                .setMessage("پن ری سیٹ کرنے کے لیے ایپ کا تمام ریکارڈ مٹانا پڑے گا۔ کیا آپ ایسا کرنا چاہتے ہیں؟")
                .setPositiveButton("ریکارڈ مٹا کر لاک ہٹائیں") { _, _ ->
                    Store.resetAll(this)
                    Reminders.scheduleAll(this)
                    AppLock.unlockNow()
                    finish()
                }
                .setNegativeButton("منسوخ", null)
                .show()
        }
        root.addView(forgot, lp(WRAP, WRAP))

        setContentView(root)
        updateDots()
    }

    private fun press(k: String) {
        if (k == "⌫") {
            if (entered.isNotEmpty()) entered = entered.dropLast(1)
        } else if (entered.length < 4) {
            entered += k
        }
        updateDots()
        if (entered.length == 4) {
            if (Store.checkPin(this, entered)) {
                AppLock.unlockNow()
                finish()
            } else {
                Toast.makeText(this, "غلط پن", Toast.LENGTH_SHORT).show()
                entered = ""
                updateDots()
            }
        }
    }

    private fun updateDots() {
        dots.text = (0 until 4).joinToString(" ") { if (it < entered.length) "●" else "○" }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        super.onDestroy()
        AppLock.showing = false
    }
}
