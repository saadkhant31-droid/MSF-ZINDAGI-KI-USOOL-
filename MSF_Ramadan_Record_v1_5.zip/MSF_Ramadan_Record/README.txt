MSF RamdanulMubarak Record - Android project

GitHub par APK banane ka tareeqa:
1. Is zip ko extract karke poora folder naye GitHub repo me upload/push karein.
2. Repo me "Actions" tab kholein -> "Build APK" workflow chalayein (ya push par khud chalega).
3. Kaam mukammal hone par "Artifacts" se MSF-RamadanulMubarak-Record-APK download karein.

Version 1.1 - naya design:
- "قضا روزوں کا ریکارڈ" aur "رمضان کے فرض روزے" screens naye design ke mutabiq (summary tiles, record table, add/edit/delete).
- Neeche navigation bar me ab: ہوم، سحری و افطاری، روزے، فرض روزے، قضا روزے، نفلی روزے، نمازیں، قرآن پاک، رپورٹس، نوٹس، سیٹنگز.

Version 1.2:
- "روزوں کی رپورٹس" (1 din / 3 din / 1 hafta / 1 mahina / 1 saal / apni tareekh) naye design ke saath, graph aur khulasa ke saath.
- "ذاتی نوٹس" categories (روزہ، قضا، نماز، سحری، افطار، قرآن، دیگر) aur waqt ke saath.

Version 1.3:
- "نمازوں کی ریکارڈز" screen نئے ڈیزائن کے مطابق: آج کی نمازوں کا خلاصہ (5 رنگین کارڈ)، چار خلاصہ ٹائلز، روزانہ کی تفصیل کا جدول (وقت، پڑھنے کا وقت، حالت، رکعات، نوٹ)، ہفتہ وار گراف اور نماز کا پیغام.
- تاریخ کے تیر / کیلنڈر سے کسی بھی دن کی نمازیں درج کریں؛ سب بٹن کام کرتے ہیں.

Version 1.4:
- "سیٹنگز" screen نئے ڈیزائن کے مطابق (آئیکن والی قطاریں، سوئچ، چپس، لاگ آؤٹ بٹن)۔ سب بٹن کام کرتے ہیں:
  میرا پروفائل (نام، شہر، تصویر)، اطلاعات کی ترتیبات (سحری/افطار/نماز/قرآن کی روزانہ یاد دہانی)،
  رمضان کی ترتیبات (پرانی سیٹنگز)، زبان، تھیم (لائٹ/ڈارک)، آواز و کمپن، خودکار لاک (4 ہندسوں کا پن)،
  ڈیٹا کا بیک اپ (فائل میں محفوظ/بحال/سب مٹائیں)، رابطہ کریں، ایپ کے بارے میں، رازداری کی پالیسی، شرائط و ضوابط، لاگ آؤٹ۔
- رابطہ کے لیے ای میل: SettingsUi.kt میں AppInfo.SUPPORT_EMAIL اپنی ای میل سے بدلیں۔

Version 1.5:
- 11 فونٹس شامل (app/src/main/assets/fonts): جمیل نوری نستعلیق، القلم قرآن (کئی اقسام)، المجید، المصحف، نورِ قرآن۔
- سیٹنگز > زبان / Language > "فونٹ منتخب کریں" سے فونٹ بدلیں؛ پوری ایپ میں لاگو ہوتا ہے۔
- نیا فونٹ شامل کرنے کے لیے .ttf فائل assets/fonts میں رکھیں اور Fonts.kt کی فہرست میں ایک سطر لکھیں۔
