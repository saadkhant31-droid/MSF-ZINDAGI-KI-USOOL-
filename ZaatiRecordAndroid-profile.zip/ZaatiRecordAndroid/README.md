# Zaati Record MSF (Android)
Offline Urdu personal-record app. UI lives in app/src/main/assets/index.html.

- **نماز کی پابندی**: home -> "نماز کی پابندی" (6 tabs: dashboard, times, details, duas, reports, settings).
- **اوقاتِ نماز (کوہاٹ)**: full-year table embedded in index.html (`NZT`); original text files are kept in
  app/src/main/assets/kohat_prayer_times/ (OCR values were cross-checked against a solar calculation for Kohat).

Push to GitHub -> Actions tab -> Build APK -> download artifact "Zaati-Record-APK".

- **اپنا واقعہ خود لکھیں**: home tile -> new screen (view `waqia`, plus `wform` / `wlist` / `wprog`).
  Add/edit/delete/share incidents, photo picker (needs MainActivity file chooser), tabs scroll to sections.

- **ایپ کی سیٹنگ**: view `set` (profile, 6 quick tiles, 5 setting groups). Prefs live in `S` (theme, font size, reading mode apply instantly).
  MainActivity JS bridge: share, rotate, vibrate, saveFile (backup to Downloads).

- **غسل کا ریکارڈ**: views `ghusl` (dashboard), `gall` (all records + filters), `gform` (add/edit). Home tile and "میرا ریکارڈ" go there.

- **ایپ کی سیٹنگ (نیا ڈیزائن)**: view `set` اب دو حصوں میں ہے (مینو + مواد): پروفائل، اکاؤنٹ، اطلاعات، سیکیورٹی، ظاہری شکل، زبان، ڈیٹا، مدد، ایپ کے بارے میں، لاگ آؤٹ۔ پروفائل ڈرافٹ `SPD` میں رہتا ہے اور "تبدیلیاں محفوظ کریں" سے `S` میں جاتا ہے۔ MainActivity bridge میں `copy` اور `openUrl` شامل ہیں۔
